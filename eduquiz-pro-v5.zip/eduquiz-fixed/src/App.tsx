import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Component, type ReactNode } from "react";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/hooks/useTheme";
import { AuthProvider, RequireAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import HomePage from "./pages/HomePage";
import QuestionBankPage from "./pages/QuestionBankPage";
import ExamListPage from "./pages/ExamListPage";
import ExamTakingPage from "./pages/ExamTakingPage";
import ExamResultPage from "./pages/ExamResultPage";
import StatisticsPage from "./pages/StatisticsPage";
import CreateExamPage from "./pages/CreateExamPage";
import AuthPage from "./pages/AuthPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// ── Error Boundary ────────────────────────────────────────
class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center p-8 bg-background">
          <div className="max-w-md w-full rounded-xl border border-destructive/30 bg-destructive/5 p-6 space-y-4">
            <h2 className="text-lg font-semibold text-destructive">Đã xảy ra lỗi</h2>
            <p className="text-sm text-muted-foreground">
              Không thể kết nối đến server. Hãy đảm bảo backend đang chạy tại{" "}
              <code className="bg-muted px-1 rounded text-xs">http://localhost:3001</code>
            </p>
            <pre className="text-xs bg-muted p-3 rounded-lg overflow-auto text-foreground">
              {(this.state.error as Error).message}
            </pre>
            <button
              onClick={() => { this.setState({ error: null }); window.location.href = "/"; }}
              className="w-full rounded-lg bg-primary text-primary-foreground py-2 text-sm font-medium hover:opacity-90"
            >
              Thử lại
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ── Protected route ────────────────────────────────────────
const Protected = ({ children }: { children: ReactNode }) => (
  <RequireAuth><AppLayout>{children}</AppLayout></RequireAuth>
);

const App = () => (
  <ThemeProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <ErrorBoundary>
              <Routes>
                {/* Public */}
                <Route path="/dang-nhap" element={<AuthPage />} />

                {/* Protected — cần đăng nhập */}
                <Route path="/"                   element={<Protected><HomePage /></Protected>} />
                <Route path="/ngan-hang-cau-hoi"  element={<Protected><QuestionBankPage /></Protected>} />
                <Route path="/thi-thu"            element={<Protected><ExamListPage /></Protected>} />
                <Route path="/lam-bai/:id"        element={<Protected><ExamTakingPage /></Protected>} />
                <Route path="/ket-qua/:id"        element={<Protected><ExamResultPage /></Protected>} />
                <Route path="/thong-ke"           element={<Protected><StatisticsPage /></Protected>} />
                <Route path="/tao-de"             element={<Protected><CreateExamPage /></Protected>} />

                <Route path="*" element={<NotFound />} />
              </Routes>
            </ErrorBoundary>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
