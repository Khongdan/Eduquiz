import { createContext, useContext, useState } from "react";
import { Navigate } from "react-router-dom";
import { apiLogin, apiRegister, apiLogout, getToken, type AuthUser } from "@/lib/api";

interface AuthCtx {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthCtx>({
  user: null,
  loading: false,
  login: async () => ({ ok: false }),
  register: async () => ({ ok: false }),
  logout: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem("eq_user");
      return saved ? JSON.parse(saved) : null;
    } catch { return null; }
  });
  const [loading, setLoading] = useState(false);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const u = await apiLogin(email, password);
      localStorage.setItem("eq_user", JSON.stringify(u));
      setUser(u);
      return { ok: true };
    } catch (err: unknown) {
      return { ok: false, error: err instanceof Error ? err.message : "Lỗi đăng nhập" };
    } finally {
      setLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string) => {
    setLoading(true);
    try {
      const u = await apiRegister(name, email, password);
      localStorage.setItem("eq_user", JSON.stringify(u));
      setUser(u);
      return { ok: true };
    } catch (err: unknown) {
      return { ok: false, error: err instanceof Error ? err.message : "Lỗi đăng ký" };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    apiLogout();
    localStorage.removeItem("eq_user");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
export type { AuthUser };

export function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user || !getToken()) {
    return <Navigate to="/dang-nhap" replace />;
  }
  return <>{children}</>;
}
