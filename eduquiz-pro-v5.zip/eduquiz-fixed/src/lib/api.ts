// ============================================================
// EduQuiz Pro – API Client (thay thế localStorage store)
// ============================================================

const BASE = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

// ---------- Token helpers ----------

export function getToken(): string | null {
  return localStorage.getItem("eq_token");
}
export function setToken(t: string) {
  localStorage.setItem("eq_token", t);
}
export function removeToken() {
  localStorage.removeItem("eq_token");
}

function headers(): HeadersInit {
  const t = getToken();
  return {
    "Content-Type": "application/json",
    ...(t ? { Authorization: `Bearer ${t}` } : {}),
  };
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: headers(),
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({ error: "Không thể kết nối đến server" }));
  if (res.status === 401) {
    // Token hết hạn → xóa và reload về trang đăng nhập
    removeToken();
    localStorage.removeItem("eq_user");
    window.location.href = "/dang-nhap";
    throw new Error("Phiên đăng nhập hết hạn");
  }
  if (!res.ok) throw new Error(data.error ?? "Lỗi server");
  return data as T;
}

// ---------- Types (giữ nguyên tương thích với store cũ) ----------

export interface AuthUser {
  name: string;
  email: string;
  avatarColor: string;
}

export interface ExamAttempt {
  id: string;
  examId: number;
  examTitle: string;
  subject: string;
  startedAt: string;
  finishedAt: string;
  durationSeconds: number;
  answers: { questionId: number; selected: number | null }[];
  score: number;
  correct: number;
  wrong: number;
  skipped: number;
  mode: "practice" | "simulation";
}

export interface QuestionStat {
  questionId: number;
  attempts: number;
  correct: number;
  lastSeen: string;
  nextReview: string;
  easeFactor: number;
  interval: number;
}

export interface UserProgress {
  totalExp: number;
  level: number;
  streak: number;
  lastStudyDate: string;
  badges: string[];
}

export interface StoredExam {
  id: number;
  title: string;
  subject: string;
  difficulty: string;
  questionCount: number;
  duration: number;
  mode: "practice" | "simulation";
  questionIds: number[];
  isCustom: boolean;
  attempted: boolean;
  year: number;
  createdAt?: string;
}

export interface StoredQuestion {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  subject: string;
  difficulty: string;
  topic: string;
  year: number;
  explanation: string;
  isCustom?: boolean;
  createdAt?: string;
}

// ---------- Auth ----------

export async function apiRegister(name: string, email: string, password: string) {
  const data = await request<{ token: string; user: AuthUser }>("POST", "/api/auth/register", { name, email, password });
  setToken(data.token);
  return data.user;
}

export async function apiLogin(email: string, password: string) {
  const data = await request<{ token: string; user: AuthUser }>("POST", "/api/auth/login", { email, password });
  setToken(data.token);
  return data.user;
}

export function apiLogout() {
  removeToken();
}

// ---------- Questions ----------

export async function apiGetQuestions(): Promise<StoredQuestion[]> {
  return request("GET", "/api/questions");
}

export async function apiSaveQuestion(q: Omit<StoredQuestion, "id" | "createdAt">): Promise<StoredQuestion> {
  return request("POST", "/api/questions", q);
}

export async function apiDeleteQuestion(id: number): Promise<void> {
  return request("DELETE", `/api/questions/${id}`);
}

// ---------- Exams ----------

export async function apiGetExams(): Promise<StoredExam[]> {
  return request("GET", "/api/exams");
}

export async function apiSaveExam(exam: Omit<StoredExam, "id" | "attempted" | "createdAt">): Promise<StoredExam> {
  return request("POST", "/api/exams", exam);
}

export async function apiDeleteExam(id: number): Promise<void> {
  return request("DELETE", `/api/exams/${id}`);
}

// ---------- Attempts ----------

export async function apiGetAttempts(): Promise<ExamAttempt[]> {
  return request("GET", "/api/attempts");
}

export async function apiGetAttemptById(id: string): Promise<ExamAttempt> {
  return request("GET", `/api/attempts/${id}`);
}

export async function apiSaveAttempt(attempt: ExamAttempt): Promise<void> {
  return request("POST", "/api/attempts", attempt);
}

// ---------- Progress ----------

export async function apiGetProgress(): Promise<UserProgress> {
  return request("GET", "/api/progress");
}

export async function apiGetQuestionStats(): Promise<Record<number, QuestionStat>> {
  return request("GET", "/api/progress/stats");
}

export async function apiUpdateQuestionStat(questionId: number, wasCorrect: boolean): Promise<void> {
  return request("POST", "/api/progress/stats", { questionId, wasCorrect });
}

export function apiGetDueForReview(questionIds: number[], stats: Record<number, QuestionStat>): number[] {
  const now = new Date();
  return questionIds.filter((id) => {
    const s = stats[id];
    if (!s) return true;
    return new Date(s.nextReview) <= now;
  });
}

// ---------- Badge catalog (không cần server) ----------

export const BADGE_CATALOG: Record<string, { label: string; icon: string; desc: string }> = {
  first_10:       { label: "Khởi đầu tốt",      icon: "⭐", desc: "Trả lời đúng 10 câu đầu tiên" },
  fifty_correct:  { label: "Học 50 câu",          icon: "🎯", desc: "Đã trả lời đúng 50 câu hỏi" },
  hundred_correct:{ label: "Trăm câu",            icon: "💯", desc: "Đã trả lời đúng 100 câu hỏi" },
  streak_3:       { label: "Liên tiếp 3 ngày",    icon: "🔥", desc: "Học liên tục 3 ngày" },
  streak_7:       { label: "Tuần lễ bùng cháy",   icon: "🚀", desc: "Học liên tục 7 ngày" },
  score_9:        { label: "Xuất sắc",             icon: "🏆", desc: "Đạt điểm 9+ trong một bài thi" },
  perfect:        { label: "Hoàn hảo",             icon: "💎", desc: "Đúng tất cả câu, không bỏ qua" },
};
