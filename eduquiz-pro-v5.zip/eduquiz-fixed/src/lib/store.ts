// ============================================================
// EduQuiz Pro – localStorage Store
// ============================================================

import { Question, Exam } from "@/data/mockData";

// ---------- Types ----------

export interface ExamAttempt {
  id: string;
  examId: number;
  examTitle: string;
  subject: string;
  startedAt: string;
  finishedAt: string;
  durationSeconds: number;
  answers: { questionId: number; selected: number | null }[];
  score: number; // 0-10
  correct: number;
  wrong: number;
  skipped: number;
  mode: "practice" | "simulation";
}

export interface QuestionStat {
  questionId: number;
  attempts: number;
  correct: number;
  lastSeen: string;
  nextReview: string; // ISO date — spaced repetition
  easeFactor: number; // SM-2 ease factor (default 2.5)
  interval: number;   // days until next review
}

export interface UserProgress {
  totalExp: number;
  level: number;
  streak: number;
  lastStudyDate: string;
  badges: string[];
}

export interface StoredExam extends Exam {
  isCustom: boolean;
  questionIds: number[];
  createdAt?: string;
}

export interface StoredQuestion extends Question {
  isCustom?: boolean;
  createdAt?: string;
}

// ---------- Keys ----------

const KEYS = {
  attempts: "eq_attempts",
  questionStats: "eq_question_stats",
  progress: "eq_progress",
  exams: "eq_exams",
  questions: "eq_questions",
} as const;

// ---------- Helpers ----------

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

// ---------- Attempts ----------

export function getAttempts(): ExamAttempt[] {
  return load<ExamAttempt[]>(KEYS.attempts, []);
}

export function saveAttempt(attempt: ExamAttempt) {
  const list = getAttempts();
  const idx = list.findIndex((a) => a.id === attempt.id);
  if (idx >= 0) list[idx] = attempt;
  else list.unshift(attempt);
  save(KEYS.attempts, list);
  updateProgressAfterAttempt(attempt);
}

export function getAttemptById(id: string): ExamAttempt | undefined {
  return getAttempts().find((a) => a.id === id);
}

// ---------- Question Stats (Spaced Repetition SM-2) ----------

export function getQuestionStats(): Record<number, QuestionStat> {
  return load<Record<number, QuestionStat>>(KEYS.questionStats, {});
}

export function updateQuestionStat(questionId: number, wasCorrect: boolean) {
  const stats = getQuestionStats();
  const today = new Date().toISOString();
  const existing: QuestionStat = stats[questionId] ?? {
    questionId,
    attempts: 0,
    correct: 0,
    lastSeen: today,
    nextReview: today,
    easeFactor: 2.5,
    interval: 1,
  };

  existing.attempts += 1;
  if (wasCorrect) existing.correct += 1;
  existing.lastSeen = today;

  // SM-2 algorithm
  const grade = wasCorrect ? 4 : 1;
  if (grade >= 3) {
    if (existing.interval === 1) existing.interval = 1;
    else if (existing.interval === 2) existing.interval = 6;
    else existing.interval = Math.round(existing.interval * existing.easeFactor);
    existing.easeFactor = Math.max(
      1.3,
      existing.easeFactor + 0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02)
    );
  } else {
    existing.interval = 1;
    existing.easeFactor = Math.max(1.3, existing.easeFactor - 0.2);
  }

  const next = new Date();
  next.setDate(next.getDate() + existing.interval);
  existing.nextReview = next.toISOString();

  stats[questionId] = existing;
  save(KEYS.questionStats, stats);
}

export function getDueForReview(questionIds: number[]): number[] {
  const stats = getQuestionStats();
  const now = new Date();
  return questionIds.filter((id) => {
    const s = stats[id];
    if (!s) return true; // never studied
    return new Date(s.nextReview) <= now;
  });
}

// ---------- Progress & Gamification ----------

const defaultProgress: UserProgress = {
  totalExp: 0,
  level: 1,
  streak: 0,
  lastStudyDate: "",
  badges: [],
};

export function getProgress(): UserProgress {
  return load<UserProgress>(KEYS.progress, defaultProgress);
}

function expForLevel(level: number) {
  return level * 200;
}

export function updateProgressAfterAttempt(attempt: ExamAttempt) {
  const prog = getProgress();

  // EXP
  const gainedExp = attempt.correct * 10 + Math.floor(attempt.score * 5);
  prog.totalExp += gainedExp;

  // Level up
  while (prog.totalExp >= expForLevel(prog.level)) {
    prog.totalExp -= expForLevel(prog.level);
    prog.level = Math.min(10, prog.level + 1);
  }

  // Streak
  const today = new Date().toDateString();
  if (prog.lastStudyDate !== today) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (prog.lastStudyDate === yesterday.toDateString()) {
      prog.streak += 1;
    } else if (prog.lastStudyDate !== today) {
      prog.streak = 1;
    }
    prog.lastStudyDate = today;
  }

  // Badges
  const attempts = getAttempts();
  const allCorrectAnswers = attempts.reduce((s, a) => s + a.correct, 0);

  const earnBadge = (id: string) => {
    if (!prog.badges.includes(id)) prog.badges.push(id);
  };

  if (allCorrectAnswers >= 10) earnBadge("first_10");
  if (allCorrectAnswers >= 50) earnBadge("fifty_correct");
  if (allCorrectAnswers >= 100) earnBadge("hundred_correct");
  if (prog.streak >= 3) earnBadge("streak_3");
  if (prog.streak >= 7) earnBadge("streak_7");
  if (attempt.score >= 9) earnBadge("score_9");
  if (attempt.correct === attempt.correct + attempt.wrong + attempt.skipped && attempt.skipped === 0 && attempt.wrong === 0)
    earnBadge("perfect");

  // Check 10-correct-in-a-row across recent attempts
  const recent = attempts.slice(0, 5);
  let streak10 = 0;
  outer: for (const a of recent) {
    for (const ans of a.answers) {
      // we don't track per-answer correctness in streak easily — skip advanced check
    }
  }

  save(KEYS.progress, prog);
}

// ---------- Dynamic Exams ----------

export function getStoredExams(): StoredExam[] {
  return load<StoredExam[]>(KEYS.exams, []);
}

export function saveExam(exam: StoredExam) {
  const list = getStoredExams();
  const idx = list.findIndex((e) => e.id === exam.id);
  if (idx >= 0) list[idx] = exam;
  else list.push(exam);
  save(KEYS.exams, list);
}

export function deleteExam(id: number) {
  const list = getStoredExams().filter((e) => e.id !== id);
  save(KEYS.exams, list);
}

// ---------- Dynamic Questions ----------

export function getStoredQuestions(): StoredQuestion[] {
  return load<StoredQuestion[]>(KEYS.questions, []);
}

export function saveQuestion(q: StoredQuestion) {
  const list = getStoredQuestions();
  const idx = list.findIndex((x) => x.id === q.id);
  if (idx >= 0) list[idx] = q;
  else list.push(q);
  save(KEYS.questions, list);
}

export function deleteQuestion(id: number) {
  const list = getStoredQuestions().filter((q) => q.id !== id);
  save(KEYS.questions, list);
}

// ---------- Badge catalog ----------

export const BADGE_CATALOG: Record<string, { label: string; icon: string; desc: string }> = {
  first_10: { label: "Khởi đầu tốt", icon: "⭐", desc: "Trả lời đúng 10 câu đầu tiên" },
  fifty_correct: { label: "Học 50 câu", icon: "🎯", desc: "Đã trả lời đúng 50 câu hỏi" },
  hundred_correct: { label: "Trăm câu", icon: "💯", desc: "Đã trả lời đúng 100 câu hỏi" },
  streak_3: { label: "Liên tiếp 3 ngày", icon: "🔥", desc: "Học liên tục 3 ngày" },
  streak_7: { label: "Tuần lễ bùng cháy", icon: "🚀", desc: "Học liên tục 7 ngày" },
  score_9: { label: "Xuất sắc", icon: "🏆", desc: "Đạt điểm 9+ trong một bài thi" },
  perfect: { label: "Hoàn hảo", icon: "💎", desc: "Đúng tất cả câu, không bỏ qua" },
};
