export const subjects = ["Toán", "Vật lý", "Hóa học", "Ngữ văn", "Tiếng Anh", "Lịch sử", "Địa lý", "Sinh học"];

export const subjectColors: Record<string, string> = {
  "Toán": "bg-blue-100 text-blue-700",
  "Vật lý": "bg-purple-100 text-purple-700",
  "Hóa học": "bg-orange-100 text-orange-700",
  "Ngữ văn": "bg-pink-100 text-pink-700",
  "Tiếng Anh": "bg-cyan-100 text-cyan-700",
  "Lịch sử": "bg-amber-100 text-amber-700",
  "Địa lý": "bg-green-100 text-green-700",
  "Sinh học": "bg-emerald-100 text-emerald-700",
};

export const difficultyColors: Record<string, string> = {
  "Dễ": "bg-green-100 text-green-700",
  "Trung bình": "bg-yellow-100 text-yellow-700",
  "Khó": "bg-orange-100 text-orange-700",
  "Rất khó": "bg-red-100 text-red-700",
};

export interface Question {
  id: number;
  subject: string;
  topic: string;
  difficulty: string;
  year: number;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const questions: Question[] = [
  { id: 1, subject: "Toán", topic: "Hàm số", difficulty: "Trung bình", year: 2024, text: "Cho hàm số y = x³ - 3x² + 2. Hàm số đồng biến trên khoảng nào?", options: ["(-∞; 0) và (2; +∞)", "(-∞; 0)", "(0; 2)", "(2; +∞)"], correctAnswer: 0, explanation: "Ta có y' = 3x² - 6x = 3x(x-2). y' > 0 khi x < 0 hoặc x > 2. Vậy hàm số đồng biến trên (-∞; 0) và (2; +∞)." },
  { id: 2, subject: "Vật lý", topic: "Dao động cơ", difficulty: "Khó", year: 2024, text: "Một con lắc lò xo dao động điều hòa với biên độ A = 5cm và tần số f = 2Hz. Vận tốc cực đại của vật là bao nhiêu?", options: ["20π cm/s", "10π cm/s", "5π cm/s", "40π cm/s"], correctAnswer: 0, explanation: "Vận tốc cực đại: vmax = ωA = 2πfA = 2π×2×5 = 20π cm/s." },
  { id: 3, subject: "Hóa học", topic: "Este - Lipit", difficulty: "Dễ", year: 2023, text: "Thủy phân este CH₃COOC₂H₅ trong môi trường axit thu được sản phẩm là?", options: ["CH₃COOH và C₂H₅OH", "CH₃OH và C₂H₅COOH", "HCOOH và CH₃OH", "CH₃COOH và CH₃OH"], correctAnswer: 0, explanation: "CH₃COOC₂H₅ + H₂O → CH₃COOH + C₂H₅OH" },
  { id: 4, subject: "Ngữ văn", topic: "Văn học hiện đại", difficulty: "Trung bình", year: 2024, text: "Tác phẩm 'Vợ nhặt' của Kim Lân phản ánh hiện thực gì của xã hội Việt Nam?", options: ["Nạn đói năm 1945", "Chiến tranh chống Pháp", "Cải cách ruộng đất", "Thời kỳ đổi mới"], correctAnswer: 0, explanation: "Vợ nhặt phản ánh nạn đói khủng khiếp năm 1945, đồng thời ca ngợi tình người và khát vọng sống." },
  { id: 5, subject: "Tiếng Anh", topic: "Grammar", difficulty: "Dễ", year: 2023, text: "Choose the correct answer: She ___ to school every day.", options: ["goes", "go", "going", "gone"], correctAnswer: 0, explanation: "Subject 'She' is third person singular, so we use 'goes' in present simple tense." },
  { id: 6, subject: "Lịch sử", topic: "Lịch sử Việt Nam", difficulty: "Trung bình", year: 2024, text: "Chiến thắng Điện Biên Phủ diễn ra vào năm nào?", options: ["1954", "1953", "1955", "1952"], correctAnswer: 0, explanation: "Chiến thắng Điện Biên Phủ diễn ra ngày 7/5/1954, chấm dứt chiến tranh Đông Dương." },
  { id: 7, subject: "Toán", topic: "Tích phân", difficulty: "Khó", year: 2024, text: "Tính tích phân I = ∫₀¹ x·eˣ dx", options: ["1", "e - 1", "e", "2"], correctAnswer: 0, explanation: "Dùng phương pháp tích phân từng phần: u = x, dv = eˣdx. I = [x·eˣ]₀¹ - ∫₀¹ eˣdx = e - (e-1) = 1." },
  { id: 8, subject: "Vật lý", topic: "Sóng điện từ", difficulty: "Rất khó", year: 2023, text: "Mạch dao động LC có L = 2mH, C = 8pF. Bước sóng điện từ mà mạch thu được là?", options: ["2,4m", "24m", "240m", "2400m"], correctAnswer: 0, explanation: "λ = c·2π√(LC) = 3×10⁸ × 2π × √(2×10⁻³ × 8×10⁻¹²) ≈ 2,4m." },
  { id: 9, subject: "Sinh học", topic: "Di truyền học", difficulty: "Trung bình", year: 2024, text: "Theo Mendel, phép lai Aa × Aa cho tỉ lệ kiểu hình là?", options: ["3:1", "1:1", "1:2:1", "9:3:3:1"], correctAnswer: 0, explanation: "Aa × Aa → 1AA : 2Aa : 1aa. Kiểu hình trội : lặn = 3:1." },
  { id: 10, subject: "Địa lý", topic: "Địa lý Việt Nam", difficulty: "Dễ", year: 2023, text: "Đồng bằng sông Cửu Long có diện tích khoảng bao nhiêu km²?", options: ["40.000 km²", "20.000 km²", "60.000 km²", "15.000 km²"], correctAnswer: 0, explanation: "Đồng bằng sông Cửu Long có diện tích khoảng 40.000 km², là đồng bằng lớn nhất Việt Nam." },
  { id: 11, subject: "Toán", topic: "Xác suất", difficulty: "Trung bình", year: 2023, text: "Gieo một con súc sắc cân đối 2 lần. Xác suất để tổng số chấm bằng 7 là?", options: ["1/6", "1/4", "1/12", "5/36"], correctAnswer: 0, explanation: "Các cặp cho tổng 7: (1,6),(2,5),(3,4),(4,3),(5,2),(6,1) = 6 cặp. P = 6/36 = 1/6." },
  { id: 12, subject: "Hóa học", topic: "Kim loại", difficulty: "Khó", year: 2024, text: "Dãy nào sau đây được xếp theo chiều tăng dần tính khử?", options: ["Cu, Fe, Al, Mg, Na, K", "K, Na, Mg, Al, Fe, Cu", "Fe, Cu, Al, Mg, K, Na", "Cu, Al, Fe, Mg, Na, K"], correctAnswer: 0, explanation: "Tính khử tăng dần: Cu < Fe < Al < Mg < Na < K theo dãy hoạt động hóa học." },
  { id: 13, subject: "Tiếng Anh", topic: "Vocabulary", difficulty: "Trung bình", year: 2024, text: "Choose the word closest in meaning to 'diligent':", options: ["hardworking", "lazy", "clever", "honest"], correctAnswer: 0, explanation: "'Diligent' means showing care and effort in work, synonymous with 'hardworking'." },
  { id: 14, subject: "Vật lý", topic: "Điện học", difficulty: "Trung bình", year: 2023, text: "Điện trở R = 10Ω, hiệu điện thế U = 5V. Cường độ dòng điện qua R là?", options: ["0,5A", "5A", "50A", "2A"], correctAnswer: 0, explanation: "Theo định luật Ohm: I = U/R = 5/10 = 0,5A." },
  { id: 15, subject: "Sinh học", topic: "Tế bào học", difficulty: "Dễ", year: 2024, text: "Bào quan nào thực hiện chức năng tổng hợp protein trong tế bào?", options: ["Ribosome", "Mitochondria", "Golgi", "Lysosome"], correctAnswer: 0, explanation: "Ribosome là bào quan tổng hợp protein, có ở tất cả các tế bào sống." },
  { id: 16, subject: "Toán", topic: "Lượng giác", difficulty: "Khó", year: 2023, text: "Giá trị của sin(75°) bằng?", options: ["(√6+√2)/4", "(√6-√2)/4", "√3/2", "√2/2"], correctAnswer: 0, explanation: "sin(75°) = sin(45°+30°) = sin45°cos30° + cos45°sin30° = (√2/2)(√3/2) + (√2/2)(1/2) = (√6+√2)/4." },
  { id: 17, subject: "Lịch sử", topic: "Lịch sử thế giới", difficulty: "Trung bình", year: 2024, text: "Chiến tranh Thế giới thứ II kết thúc năm nào?", options: ["1945", "1944", "1946", "1943"], correctAnswer: 0, explanation: "Chiến tranh Thế giới thứ II kết thúc năm 1945: Đức đầu hàng tháng 5, Nhật đầu hàng tháng 8." },
  { id: 18, subject: "Hóa học", topic: "Hóa hữu cơ", difficulty: "Trung bình", year: 2023, text: "Công thức phân tử của axit acetic là?", options: ["CH₃COOH", "HCOOH", "C₂H₅OH", "CH₃OH"], correctAnswer: 0, explanation: "Axit acetic (giấm ăn) có công thức CH₃COOH hay C₂H₄O₂." },
  { id: 19, subject: "Địa lý", topic: "Địa lý thế giới", difficulty: "Dễ", year: 2024, text: "Châu lục nào có diện tích lớn nhất thế giới?", options: ["Châu Á", "Châu Phi", "Châu Mỹ", "Châu Âu"], correctAnswer: 0, explanation: "Châu Á là châu lục lớn nhất thế giới với diện tích khoảng 44,6 triệu km²." },
  { id: 20, subject: "Ngữ văn", topic: "Tiếng Việt", difficulty: "Dễ", year: 2023, text: "Biện pháp tu từ nào được sử dụng trong câu: 'Mặt trời của bắp thì nằm trên đồi'?", options: ["Ẩn dụ", "So sánh", "Nhân hóa", "Hoán dụ"], correctAnswer: 0, explanation: "Đây là ẩn dụ: 'Mặt trời của bắp' ẩn dụ cho ánh sáng/nguồn sống cần thiết cho cây bắp." },
];

export interface Exam {
  id: number;
  title: string;
  subject: string;
  year: number;
  difficulty: string;
  questionCount: number;
  duration: number;
  mode: "practice" | "simulation";
  lastScore?: number;
  attempted: boolean;
}

export const exams: Exam[] = [
  { id: 1, title: "Đề thi THPT QG Toán 2024", subject: "Toán", year: 2024, difficulty: "Khó", questionCount: 50, duration: 90, mode: "simulation", lastScore: 7.5, attempted: true },
  { id: 2, title: "Luyện tập Vật lý - Dao động cơ", subject: "Vật lý", year: 2024, difficulty: "Trung bình", questionCount: 30, duration: 45, mode: "practice", lastScore: 8.0, attempted: true },
  { id: 3, title: "Đề thi Hóa học HK2 2024", subject: "Hóa học", year: 2024, difficulty: "Trung bình", questionCount: 40, duration: 60, mode: "simulation", attempted: false },
  { id: 4, title: "Ngữ văn - Văn học hiện đại", subject: "Ngữ văn", year: 2023, difficulty: "Dễ", questionCount: 20, duration: 30, mode: "practice", attempted: false },
  { id: 5, title: "English Grammar Practice", subject: "Tiếng Anh", year: 2024, difficulty: "Dễ", questionCount: 40, duration: 60, mode: "practice", lastScore: 9.0, attempted: true },
  { id: 6, title: "Đề thi Lịch sử THPT 2024", subject: "Lịch sử", year: 2024, difficulty: "Khó", questionCount: 40, duration: 50, mode: "simulation", attempted: false },
  { id: 7, title: "Sinh học - Di truyền học", subject: "Sinh học", year: 2023, difficulty: "Rất khó", questionCount: 35, duration: 50, mode: "practice", lastScore: 6.5, attempted: true },
  { id: 8, title: "Địa lý Việt Nam tổng hợp", subject: "Địa lý", year: 2024, difficulty: "Trung bình", questionCount: 30, duration: 45, mode: "simulation", attempted: false },
];

export const recentHistory = [
  { date: "05/04/2026", exam: "Đề thi THPT QG Toán 2024", subject: "Toán", score: 7.5, time: "42:15", mode: "Thi mô phỏng" },
  { date: "04/04/2026", exam: "Luyện tập Vật lý - Dao động cơ", subject: "Vật lý", score: 8.0, time: "35:20", mode: "Luyện tập" },
  { date: "03/04/2026", exam: "English Grammar Practice", subject: "Tiếng Anh", score: 9.0, time: "28:45", mode: "Luyện tập" },
  { date: "02/04/2026", exam: "Sinh học - Di truyền học", subject: "Sinh học", score: 6.5, time: "48:30", mode: "Luyện tập" },
  { date: "01/04/2026", exam: "Đề thi Hóa học HK2 2024", subject: "Hóa học", score: 7.0, time: "55:10", mode: "Thi mô phỏng" },
  { date: "31/03/2026", exam: "Toán - Hàm số lượng giác", subject: "Toán", score: 8.5, time: "40:00", mode: "Luyện tập" },
];

export const scoreOverTime = [
  { date: "01/03", Toán: 6.5, "Vật lý": 7.0, "Hóa học": 6.0, "Tiếng Anh": 8.0 },
  { date: "08/03", Toán: 7.0, "Vật lý": 7.5, "Hóa học": 6.5, "Tiếng Anh": 8.5 },
  { date: "15/03", Toán: 6.8, "Vật lý": 7.0, "Hóa học": 7.0, "Tiếng Anh": 8.0 },
  { date: "22/03", Toán: 7.5, "Vật lý": 8.0, "Hóa học": 7.5, "Tiếng Anh": 9.0 },
  { date: "29/03", Toán: 7.2, "Vật lý": 7.5, "Hóa học": 7.0, "Tiếng Anh": 8.5 },
  { date: "05/04", Toán: 7.5, "Vật lý": 8.0, "Hóa học": 7.5, "Tiếng Anh": 9.0 },
];

export const accuracyBySubject = [
  { subject: "Toán", accuracy: 72 },
  { subject: "Vật lý", accuracy: 78 },
  { subject: "Hóa học", accuracy: 65 },
  { subject: "Ngữ văn", accuracy: 80 },
  { subject: "Tiếng Anh", accuracy: 88 },
  { subject: "Lịch sử", accuracy: 70 },
  { subject: "Địa lý", accuracy: 75 },
  { subject: "Sinh học", accuracy: 68 },
];

export const weakTopics = [
  { subject: "Hóa học", topic: "Este - Lipit", accuracy: 45, questionCount: 30 },
  { subject: "Toán", topic: "Tích phân", accuracy: 52, questionCount: 25 },
  { subject: "Sinh học", topic: "Sinh thái học", accuracy: 48, questionCount: 20 },
  { subject: "Vật lý", topic: "Sóng điện từ", accuracy: 55, questionCount: 18 },
  { subject: "Lịch sử", topic: "Lịch sử thế giới", accuracy: 50, questionCount: 22 },
];
