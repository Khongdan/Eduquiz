import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Clock, Flag, ChevronLeft, ChevronRight, CheckCircle2, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { questions as baseQuestions, subjectColors, difficultyColors } from "@/data/mockData";
import {
  apiGetQuestions, apiGetExams, apiSaveAttempt, apiUpdateQuestionStat,
} from "@/lib/api";
import type { ExamAttempt, StoredQuestion, StoredExam } from "@/lib/api";

type AnswerState = { selected: number | null; checked: boolean; flagged: boolean };

export default function ExamTakingPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [examQuestions, setExamQuestions] = useState<StoredQuestion[]>([]);
  const [customExam, setCustomExam] = useState<StoredExam | null>(null);

  const [current, setCurrent] = useState(0);
  const [slideDir, setSlideDir] = useState<"left" | "right" | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [answers, setAnswers] = useState<AnswerState[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const startTime = useRef(Date.now());
  const answersRef = useRef(answers);
  answersRef.current = answers;

  // Tải dữ liệu exam và questions từ API
  useEffect(() => {
    async function load() {
      const [customQuestions, customExams] = await Promise.all([
        apiGetQuestions(),
        apiGetExams(),
      ]);
      const allQuestions = [...baseQuestions, ...customQuestions] as StoredQuestion[];
      const exam = customExams.find((e) => e.id === Number(id)) ?? null;
      setCustomExam(exam);

      const qs = exam
        ? allQuestions.filter((q) => exam.questionIds.includes(q.id)).slice(0, exam.questionCount)
        : allQuestions.slice(0, 10) as StoredQuestion[];

      setExamQuestions(qs);
      setAnswers(qs.map(() => ({ selected: null, checked: false, flagged: false })));
      setTimeLeft((exam?.duration ?? 45) * 60);
      setLoading(false);
    }
    load();
  }, [id]);

  const examMode = customExam?.mode ?? "practice";
  const examTitle = customExam?.title ?? "Đề thi THPT QG Toán 2024";

  const handleSubmit = useCallback(async (auto = false) => {
    if (submitted || examQuestions.length === 0) return;
    setSubmitted(true);
    setShowSubmitDialog(false);

    const currentAnswers = answersRef.current;
    const durationSec = Math.floor((Date.now() - startTime.current) / 1000);
    const correct = currentAnswers.filter((a, i) => a.selected === examQuestions[i].correctAnswer).length;
    const skipped = currentAnswers.filter((a) => a.selected === null).length;
    const wrong = examQuestions.length - correct - skipped;
    const score = parseFloat(((correct / examQuestions.length) * 10).toFixed(1));

    // Cập nhật stats từng câu
    await Promise.all(
      currentAnswers.map((a, i) =>
        a.selected !== null
          ? apiUpdateQuestionStat(examQuestions[i].id, a.selected === examQuestions[i].correctAnswer)
          : Promise.resolve()
      )
    );

    const attempt: ExamAttempt = {
      id: `${Date.now()}`,
      examId: Number(id) || 1,
      examTitle,
      subject: customExam?.subject ?? examQuestions[0]?.subject ?? "Toán",
      startedAt: new Date(startTime.current).toISOString(),
      finishedAt: new Date().toISOString(),
      durationSeconds: durationSec,
      answers: currentAnswers.map((a, i) => ({ questionId: examQuestions[i].id, selected: a.selected })),
      score,
      correct,
      wrong,
      skipped,
      mode: examMode,
    };

    await apiSaveAttempt(attempt);
    navigate(`/ket-qua/${attempt.id}`);
  }, [submitted, examQuestions, examMode, examTitle, id, customExam]);

  useEffect(() => {
    if (submitted || loading || timeLeft === 0) return;
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) { clearInterval(interval); handleSubmit(true); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [submitted, handleSubmit, loading, timeLeft]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60).toString().padStart(2, "0");
    const sec = (s % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  };

  const goTo = (index: number) => {
    if (isAnimating || index === current) return;
    const dir = index > current ? "left" : "right";
    setSlideDir(dir);
    setIsAnimating(true);
    setTimeout(() => {
      setCurrent(index);
      setSlideDir(null);
      setIsAnimating(false);
    }, 220);
  };

  const selectAnswer = (idx: number) => {
    if (answers[current]?.checked || submitted) return;
    setAnswers((prev) => prev.map((ans, i) => i === current ? { ...ans, selected: idx } : ans));
  };

  const checkAnswer = () => {
    if (examMode === "simulation") return;
    const q = examQuestions[current];
    const a = answers[current];
    setAnswers((prev) => prev.map((ans, i) => i === current ? { ...ans, checked: true } : ans));
    apiUpdateQuestionStat(q.id, a.selected === q.correctAnswer);
  };

  const toggleFlag = () => {
    setAnswers((prev) => prev.map((ans, i) => i === current ? { ...ans, flagged: !ans.flagged } : ans));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const q = examQuestions[current];
  const a = answers[current];
  const answered = answers.filter((a2) => a2.selected !== null).length;
  const flaggedCount = answers.filter((a2) => a2.flagged).length;
  const isCorrect = a?.checked && a.selected === q?.correctAnswer;
  const timeCritical = timeLeft < 300;

  const getNavColor = (i: number) => {
    const ans = answers[i];
    if (!ans) return "bg-muted text-muted-foreground";
    if (ans.flagged) return "bg-yellow-400 text-white";
    if (submitted || ans.checked) {
      return ans.selected === examQuestions[i].correctAnswer
        ? "bg-green-500 text-white"
        : ans.selected !== null ? "bg-red-500 text-white" : "bg-muted text-muted-foreground";
    }
    if (ans.selected !== null) return "bg-primary text-primary-foreground";
    return "bg-muted text-muted-foreground";
  };

  return (
    <div className="min-h-screen bg-background animate-fade-in">
      {/* Header */}
      <div className="sticky top-16 z-40 border-b border-border bg-card px-4 py-3">
        <div className="container mx-auto space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-foreground text-sm lg:text-base truncate max-w-xs">{examTitle}</h2>
            <div className="flex items-center gap-3">
              <Badge variant={examMode === "simulation" ? "destructive" : "secondary"}>
                {examMode === "simulation" ? "Thi mô phỏng" : "Luyện tập"}
              </Badge>
              <span className={`flex items-center gap-1 font-mono font-bold text-sm ${timeCritical ? "text-destructive animate-pulse" : "text-foreground"}`}>
                <Clock className="h-4 w-4" />{formatTime(timeLeft)}
              </span>
              <Button size="sm" variant="destructive" onClick={() => setShowSubmitDialog(true)}>Nộp bài</Button>
            </div>
          </div>
          <Progress value={(answered / examQuestions.length) * 100} className="h-1.5" />
          <div className="flex gap-4 text-xs text-muted-foreground">
            <span>Đã làm: <strong>{answered}/{examQuestions.length}</strong></span>
            <span>Đánh dấu: <strong>{flaggedCount}</strong></span>
            {timeCritical && <span className="text-destructive font-semibold flex items-center gap-1"><AlertTriangle className="h-3 w-3" />Sắp hết giờ!</span>}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar */}
          <div className="lg:w-64 shrink-0 order-2 lg:order-1">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">Câu {current + 1}/{examQuestions.length}</span>
                  <Button variant="ghost" size="sm" onClick={toggleFlag} className={a?.flagged ? "text-yellow-500" : ""}>
                    <Flag className="h-4 w-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-5 gap-1.5">
                  {examQuestions.map((_, i) => (
                    <button key={i} onClick={() => goTo(i)}
                      className={`h-8 w-8 rounded-lg text-xs font-bold transition-colors ${i === current ? "ring-2 ring-primary" : ""} ${getNavColor(i)}`}>
                      {i + 1}
                    </button>
                  ))}
                </div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2"><div className="h-3 w-3 rounded bg-muted border" />Chưa làm</div>
                  <div className="flex items-center gap-2"><div className="h-3 w-3 rounded bg-primary" />Đã chọn</div>
                  <div className="flex items-center gap-2"><div className="h-3 w-3 rounded bg-yellow-400" />Đánh dấu</div>
                  <div className="flex items-center gap-2"><div className="h-3 w-3 rounded bg-green-500" />Đúng</div>
                  <div className="flex items-center gap-2"><div className="h-3 w-3 rounded bg-red-500" />Sai</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Question */}
          <div className="flex-1 order-1 lg:order-2 space-y-4">
            <div className={`transition-all duration-200 ${
              slideDir === "left" ? "opacity-0 -translate-x-6"
              : slideDir === "right" ? "opacity-0 translate-x-6"
              : "opacity-100 translate-x-0"
            }`}>
              <Card>
                <CardContent className="p-6 space-y-6">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-primary/10 text-primary font-bold">Câu {current + 1}</Badge>
                    <Badge variant="secondary" className={subjectColors[q.subject]}>{q.subject}</Badge>
                    <Badge variant="secondary" className={difficultyColors[q.difficulty]}>{q.difficulty}</Badge>
                  </div>
                  <p className="text-base lg:text-lg font-medium text-foreground leading-relaxed">{q.text}</p>

                  <div className="space-y-3">
                    {q.options.map((opt, idx) => {
                      const letter = String.fromCharCode(65 + idx);
                      const showResult = a?.checked || (submitted && examMode === "simulation");
                      let classes = "border-border bg-card hover:border-primary/50 hover:bg-primary/5";
                      if (a?.selected === idx && !showResult) classes = "border-primary bg-primary text-primary-foreground";
                      if (showResult && idx === q.correctAnswer) classes = "border-green-500 bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300";
                      if (showResult && a?.selected === idx && idx !== q.correctAnswer) classes = "border-red-500 bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300";
                      return (
                        <button key={idx} onClick={() => selectAnswer(idx)}
                          className={`w-full flex items-center gap-3 rounded-xl border-2 p-4 text-left transition-all ${classes}`}>
                          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted font-bold text-sm">{letter}</span>
                          <span className="text-sm">{opt}</span>
                          {showResult && idx === q.correctAnswer && <CheckCircle2 className="ml-auto h-5 w-5 text-green-500" />}
                          {showResult && a?.selected === idx && idx !== q.correctAnswer && <XCircle className="ml-auto h-5 w-5 text-red-500" />}
                        </button>
                      );
                    })}
                  </div>

                  {examMode === "practice" && !a?.checked && a?.selected !== null && (
                    <Button onClick={checkAnswer}>Kiểm tra đáp án</Button>
                  )}

                  {(a?.checked || (submitted && examMode === "simulation")) && (
                    <div className={`rounded-xl p-4 ${isCorrect ? "bg-green-50 border border-green-200 dark:bg-green-950" : "bg-red-50 border border-red-200 dark:bg-red-950"}`}>
                      <p className={`font-bold mb-2 ${isCorrect ? "text-green-700 dark:text-green-300" : "text-red-700 dark:text-red-300"}`}>
                        {isCorrect ? "✓ Chính xác!" : a?.selected === null ? "⚠ Bỏ qua" : "✗ Sai rồi!"}
                      </p>
                      <p className="text-sm font-medium mb-1">Đáp án đúng: <strong>{String.fromCharCode(65 + q.correctAnswer)}</strong></p>
                      <p className="text-sm text-muted-foreground"><strong>Giải thích:</strong> {q.explanation}</p>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <Button variant="outline" disabled={current === 0} onClick={() => goTo(current - 1)}>
                      <ChevronLeft className="mr-1 h-4 w-4" />Câu trước
                    </Button>
                    {current < examQuestions.length - 1 ? (
                      <Button variant="outline" onClick={() => goTo(current + 1)}>
                        Câu tiếp theo<ChevronRight className="ml-1 h-4 w-4" />
                      </Button>
                    ) : (
                      <Button onClick={() => setShowSubmitDialog(true)} variant="destructive">Nộp bài</Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Xác nhận nộp bài</DialogTitle>
            <DialogDescription>
              Bạn đã làm {answered}/{examQuestions.length} câu. Còn {examQuestions.length - answered} câu chưa trả lời.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 mt-4">
            <Button variant="outline" className="flex-1" onClick={() => setShowSubmitDialog(false)}>Làm tiếp</Button>
            <Button className="flex-1" variant="destructive" onClick={() => handleSubmit()}>Nộp bài</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
