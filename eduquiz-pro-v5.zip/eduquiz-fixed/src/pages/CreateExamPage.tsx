import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Check, ChevronRight, Settings, Eye, BookOpen, Shuffle, Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { questions as baseQuestions, subjects, subjectColors, difficultyColors } from "@/data/mockData";
import { apiGetQuestions, apiSaveExam, apiSaveQuestion } from "@/lib/api";
import type { StoredExam, StoredQuestion } from "@/lib/api";

const steps = [
  { icon: BookOpen, label: "Chọn câu hỏi" },
  { icon: Settings, label: "Cấu hình đề" },
  { icon: Eye, label: "Xem trước & Lưu" },
];

export default function CreateExamPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [selectedQs, setSelectedQs] = useState<number[]>([]);
  const [mode, setMode] = useState<"practice" | "simulation">("practice");
  const [csvImportResult, setCsvImportResult] = useState<{ added: number; failed: number; status: "success" | "warning" | "error" } | null>(null);
  const [shuffleQ, setShuffleQ] = useState(true);
  const [shuffleA, setShuffleA] = useState(false);
  const [allowReview, setAllowReview] = useState(true);
  const [examTitle, setExamTitle] = useState("");
  const [examSubject, setExamSubject] = useState("");
  const [examDuration, setExamDuration] = useState(60);
  const [filterSubject, setFilterSubject] = useState("all");
  const [filterDiff, setFilterDiff] = useState("all");
  const [addTab, setAddTab] = useState("bank");
  const [customQuestions, setCustomQuestions] = useState<StoredQuestion[]>([]);

  const [newQ, setNewQ] = useState({ text: "", opt0: "", opt1: "", opt2: "", opt3: "", correct: 0, subject: "", difficulty: "Trung bình", topic: "", explanation: "" });

  useEffect(() => {
    apiGetQuestions().then(setCustomQuestions);
  }, []);

  const allQuestions = [...baseQuestions, ...customQuestions] as StoredQuestion[];
  const filtered = allQuestions.filter((q) => {
    const subOk = filterSubject === "all" || q.subject === filterSubject;
    const diffOk = filterDiff === "all" || q.difficulty === filterDiff;
    return subOk && diffOk;
  });

  const toggleQ = (id: number) => {
    setSelectedQs((prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]);
  };

  const handleAddManualQ = async () => {
    if (!newQ.text || !newQ.opt0 || !newQ.opt1 || !newQ.subject) return;
    const saved = await apiSaveQuestion({
      text: newQ.text,
      options: [newQ.opt0, newQ.opt1, newQ.opt2, newQ.opt3].filter(Boolean),
      correctAnswer: newQ.correct,
      subject: newQ.subject,
      difficulty: newQ.difficulty,
      topic: newQ.topic || "Khác",
      year: new Date().getFullYear(),
      explanation: newQ.explanation || "Không có giải thích",
      isCustom: true,
    });
    setCustomQuestions((prev) => [...prev, saved]);
    setSelectedQs((prev) => [...prev, saved.id]);
    setNewQ({ text: "", opt0: "", opt1: "", opt2: "", opt3: "", correct: 0, subject: "", difficulty: "Trung bình", topic: "", explanation: "" });
    toast({ title: "✅ Đã thêm câu hỏi", description: `Câu #${saved.id} đã được thêm vào ngân hàng và chọn` });
  };

  const handleCSVImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvImportResult(null);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split("\n").slice(1);
      let added = 0;
      let failed = 0;
      for (const line of lines) {
        if (!line.trim()) continue;
        const cols = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
        if (cols.length < 7) { failed++; continue; }
        const [qtext, opt0, opt1, opt2, opt3, correctStr, subject] = cols;
        if (!qtext || !opt0) { failed++; continue; }
        try {
          const saved = await apiSaveQuestion({
            text: qtext, options: [opt0, opt1, opt2, opt3].filter(Boolean),
            correctAnswer: parseInt(correctStr) || 0,
            subject: subject || "Khác", difficulty: "Trung bình", topic: "Import",
            year: new Date().getFullYear(), explanation: cols[7] || "Không có giải thích", isCustom: true,
          });
          setCustomQuestions((prev) => [...prev, saved]);
          added++;
        } catch { failed++; }
      }
      const status = added === 0 ? "error" : failed > 0 ? "warning" : "success";
      setCsvImportResult({ added, failed, status });
      if (added > 0) {
        toast({ title: "✅ Import thành công", description: `Đã thêm ${added} câu hỏi${failed > 0 ? `, bỏ qua ${failed} dòng lỗi` : ""}` });
      }
    };
    reader.onerror = () => setCsvImportResult({ added: 0, failed: 0, status: "error" });
    reader.readAsText(file, "UTF-8");
    e.target.value = "";
  };

  const handleSave = async () => {
    const exam = await apiSaveExam({
      title: examTitle || "Đề thi mới",
      subject: examSubject || "Toán",
      year: new Date().getFullYear(),
      difficulty: "Trung bình",
      questionCount: selectedQs.length,
      duration: examDuration,
      mode,
      isCustom: true,
      questionIds: shuffleQ ? [...selectedQs].sort(() => Math.random() - 0.5) : selectedQs,
    });
    navigate(`/lam-bai/${exam.id}`);
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold text-foreground">Tạo bài thi</h1>

      {/* Steps */}
      <div className="flex items-center justify-center gap-2">
        {steps.map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <button onClick={() => i < step && setStep(i)}
              className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${i === step ? "bg-primary text-primary-foreground" : i < step ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" : "bg-muted text-muted-foreground"}`}>
              {i < step ? <Check className="h-4 w-4" /> : <s.icon className="h-4 w-4" />}
              <span className="hidden sm:inline">{s.label}</span>
              <span className="sm:hidden">{i + 1}</span>
            </button>
            {i < steps.length - 1 && <ChevronRight className="h-4 w-4 text-muted-foreground" />}
          </div>
        ))}
      </div>

      {/* Step 1: Choose questions */}
      {step === 0 && (
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <Tabs value={addTab} onValueChange={setAddTab}>
              <TabsList>
                <TabsTrigger value="bank">Ngân hàng câu hỏi</TabsTrigger>
                <TabsTrigger value="manual">Thêm thủ công</TabsTrigger>
                <TabsTrigger value="csv">Import CSV</TabsTrigger>
              </TabsList>
            </Tabs>

            {addTab === "bank" && (
              <>
                <div className="flex gap-3">
                  <Select value={filterSubject} onValueChange={setFilterSubject}>
                    <SelectTrigger className="w-40"><SelectValue placeholder="Môn học" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tất cả</SelectItem>
                      {subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Select value={filterDiff} onValueChange={setFilterDiff}>
                    <SelectTrigger className="w-32"><SelectValue placeholder="Độ khó" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tất cả</SelectItem>
                      {["Dễ", "Trung bình", "Khó", "Rất khó"].map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm" onClick={() => setSelectedQs(filtered.map((q) => q.id))}>
                    Chọn tất cả
                  </Button>
                </div>
                <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1">
                  {filtered.map((q) => (
                    <Card key={q.id} className={`cursor-pointer transition-colors ${selectedQs.includes(q.id) ? "ring-2 ring-primary" : ""}`} onClick={() => toggleQ(q.id)}>
                      <CardContent className="p-3 flex items-start gap-3">
                        <Checkbox checked={selectedQs.includes(q.id)} onCheckedChange={() => toggleQ(q.id)} />
                        <div className="flex-1 min-w-0">
                          <div className="flex gap-2 mb-1 flex-wrap">
                            <Badge variant="secondary" className={subjectColors[q.subject]}>{q.subject}</Badge>
                            <Badge variant="secondary" className={difficultyColors[q.difficulty]}>{q.difficulty}</Badge>
                          </div>
                          <p className="text-sm text-foreground line-clamp-2">{q.text}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}

            {addTab === "manual" && (
              <Card>
                <CardContent className="p-5 space-y-4">
                  <h3 className="font-semibold">Thêm câu hỏi mới</h3>
                  <div className="space-y-2">
                    <Label>Nội dung câu hỏi</Label>
                    <Textarea placeholder="Nhập nội dung câu hỏi..." value={newQ.text} onChange={(e) => setNewQ((p) => ({ ...p, text: e.target.value }))} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {["opt0", "opt1", "opt2", "opt3"].map((k, i) => (
                      <div key={k} className="space-y-1">
                        <Label>Đáp án {String.fromCharCode(65 + i)}</Label>
                        <Input placeholder={`Đáp án ${String.fromCharCode(65 + i)}`} value={(newQ as any)[k]}
                          onChange={(e) => setNewQ((p) => ({ ...p, [k]: e.target.value }))} />
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <Label>Đáp án đúng</Label>
                      <Select value={String(newQ.correct)} onValueChange={(v) => setNewQ((p) => ({ ...p, correct: parseInt(v) }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {["A", "B", "C", "D"].map((l, i) => <SelectItem key={i} value={String(i)}>{l}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label>Môn học</Label>
                      <Select value={newQ.subject} onValueChange={(v) => setNewQ((p) => ({ ...p, subject: v }))}>
                        <SelectTrigger><SelectValue placeholder="Chọn môn" /></SelectTrigger>
                        <SelectContent>{subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label>Độ khó</Label>
                      <Select value={newQ.difficulty} onValueChange={(v) => setNewQ((p) => ({ ...p, difficulty: v }))}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>{["Dễ", "Trung bình", "Khó", "Rất khó"].map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label>Giải thích đáp án</Label>
                    <Textarea placeholder="Giải thích tại sao đáp án đúng..." value={newQ.explanation} onChange={(e) => setNewQ((p) => ({ ...p, explanation: e.target.value }))} />
                  </div>
                  <Button onClick={handleAddManualQ} className="w-full">Thêm và chọn câu hỏi này</Button>
                </CardContent>
              </Card>
            )}

            {addTab === "csv" && (
              <Card>
                <CardContent className="p-5 space-y-4">
                  <h3 className="font-semibold">Import từ file CSV</h3>
                  <p className="text-sm text-muted-foreground">Format: text, opt_A, opt_B, opt_C, opt_D, correct_index(0-3), subject, explanation</p>
                  <label className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-8 cursor-pointer hover:border-primary transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                    <span className="text-sm text-muted-foreground">Chọn file CSV</span>
                    <input type="file" accept=".csv" className="hidden" onChange={handleCSVImport} />
                  </label>
                  {csvImportResult && (
                    <div className={`rounded-xl border px-4 py-3 text-sm flex items-start gap-3 ${
                      csvImportResult.status === "success"
                        ? "border-green-300 bg-green-50 text-green-800 dark:border-green-800 dark:bg-green-950/40 dark:text-green-300"
                        : csvImportResult.status === "warning"
                        ? "border-yellow-300 bg-yellow-50 text-yellow-800 dark:border-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-300"
                        : "border-red-300 bg-red-50 text-red-800 dark:border-red-800 dark:bg-red-950/40 dark:text-red-300"
                    }`}>
                      <span className="text-lg leading-none mt-0.5">
                        {csvImportResult.status === "success" ? "✅" : csvImportResult.status === "warning" ? "⚠️" : "❌"}
                      </span>
                      <div>
                        {csvImportResult.added > 0 ? (
                          <p className="font-semibold">Đã thêm {csvImportResult.added} câu hỏi vào ngân hàng</p>
                        ) : (
                          <p className="font-semibold">Không thêm được câu hỏi nào</p>
                        )}
                        {csvImportResult.failed > 0 && (
                          <p className="mt-0.5 opacity-80">Bỏ qua {csvImportResult.failed} dòng lỗi (thiếu cột hoặc dữ liệu không hợp lệ)</p>
                        )}
                        {csvImportResult.status === "error" && csvImportResult.added === 0 && (
                          <p className="mt-0.5 opacity-80">Kiểm tra lại định dạng file CSV theo hướng dẫn bên trên.</p>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <Card className="lg:w-72 shrink-0 h-fit sticky top-24">
            <CardContent className="p-4">
              <h3 className="font-semibold text-foreground mb-2">Câu đã chọn ({selectedQs.length})</h3>
              {selectedQs.length === 0 ? (
                <p className="text-sm text-muted-foreground">Chưa chọn câu hỏi nào</p>
              ) : (
                <div className="flex flex-wrap gap-1 max-h-40 overflow-y-auto">
                  {selectedQs.map((id) => (
                    <Badge key={id} variant="secondary" className="cursor-pointer" onClick={() => toggleQ(id)}>Câu {id} ×</Badge>
                  ))}
                </div>
              )}
              <Button className="w-full mt-4" disabled={selectedQs.length === 0} onClick={() => setStep(1)}>
                Tiếp tục <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 2: Configure */}
      {step === 1 && (
        <Card className="max-w-lg mx-auto">
          <CardContent className="p-6 space-y-5">
            <div className="space-y-2"><Label>Tên bài thi *</Label><Input placeholder="VD: Đề thi THPT QG Toán 2024" value={examTitle} onChange={(e) => setExamTitle(e.target.value)} /></div>
            <div className="space-y-2">
              <Label>Môn học *</Label>
              <Select value={examSubject} onValueChange={setExamSubject}>
                <SelectTrigger><SelectValue placeholder="Chọn môn" /></SelectTrigger>
                <SelectContent>{subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Thời gian làm bài (phút)</Label>
              <Input type="number" value={examDuration} onChange={(e) => setExamDuration(parseInt(e.target.value) || 60)} min={5} max={180} />
            </div>
            <div className="space-y-2">
              <Label>Chế độ</Label>
              <div className="flex gap-3">
                <Button variant={mode === "practice" ? "default" : "outline"} onClick={() => { setMode("practice"); setAllowReview(true); }}>Luyện tập</Button>
                <Button variant={mode === "simulation" ? "default" : "outline"} onClick={() => { setMode("simulation"); setAllowReview(false); }}>Thi mô phỏng</Button>
              </div>
            </div>
            <div className="flex items-center justify-between"><Label>Xáo trộn câu hỏi</Label><Switch checked={shuffleQ} onCheckedChange={setShuffleQ} /></div>
            <div className="flex items-center justify-between"><Label>Xáo trộn đáp án</Label><Switch checked={shuffleA} onCheckedChange={setShuffleA} /></div>
            <div className="flex items-center justify-between">
              <Label className={mode === "simulation" ? "text-muted-foreground" : ""}>Cho phép xem lại đáp án</Label>
              <Switch checked={allowReview} onCheckedChange={setAllowReview} disabled={mode === "simulation"} />
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(0)}>Quay lại</Button>
              <Button className="flex-1" disabled={!examTitle || !examSubject} onClick={() => setStep(2)}>Tiếp tục <ChevronRight className="ml-1 h-4 w-4" /></Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Preview & Save */}
      {step === 2 && (
        <div className="max-w-2xl mx-auto space-y-4">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <Shuffle className="h-5 w-5 text-primary" />
              <div>
                <p className="font-semibold text-foreground">{examTitle}</p>
                <p className="text-sm text-muted-foreground">{selectedQs.length} câu · {examDuration} phút · {mode === "practice" ? "Luyện tập" : "Thi mô phỏng"}</p>
              </div>
            </CardContent>
          </Card>
          <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
            {selectedQs.map((id, idx) => {
              const q = allQuestions.find((qq) => qq.id === id);
              if (!q) return null;
              return (
                <Card key={id}>
                  <CardContent className="p-4">
                    <div className="flex gap-2 mb-2">
                      <Badge className="bg-primary/10 text-primary">Câu {idx + 1}</Badge>
                      <Badge variant="secondary" className={subjectColors[q.subject]}>{q.subject}</Badge>
                    </div>
                    <p className="text-sm text-foreground">{q.text}</p>
                    <div className="mt-2 space-y-1">
                      {q.options.map((opt, i) => (
                        <p key={i} className={`text-sm ${i === q.correctAnswer ? "text-green-600 font-medium" : "text-muted-foreground"}`}>
                          {String.fromCharCode(65 + i)}. {opt} {i === q.correctAnswer ? "✓" : ""}
                        </p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(1)}>Quay lại</Button>
            <Button className="flex-1" onClick={handleSave}>💾 Lưu & Bắt đầu thi</Button>
          </div>
        </div>
      )}
    </div>
  );
}
