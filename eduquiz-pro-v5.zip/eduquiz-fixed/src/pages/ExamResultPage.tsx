import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { CheckCircle2, XCircle, Clock, BarChart3, RotateCcw, Home, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { questions as baseQuestions, subjectColors } from "@/data/mockData";
import { apiGetAttemptById, apiGetQuestions } from "@/lib/api";
import type { ExamAttempt, StoredQuestion } from "@/lib/api";

export default function ExamResultPage() {
  const { id } = useParams<{ id: string }>();
  const [attempt, setAttempt] = useState<ExamAttempt | null>(null);
  const [allQuestions, setAllQuestions] = useState<StoredQuestion[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!id) return;
      const [att, customQs] = await Promise.all([
        apiGetAttemptById(id),
        apiGetQuestions(),
      ]);
      setAttempt(att);
      setAllQuestions([...baseQuestions as StoredQuestion[], ...customQs]);
      setLoading(false);
    }
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!attempt) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p className="text-muted-foreground">Không tìm thấy kết quả.</p>
        <Button asChild className="mt-4"><Link to="/">Về trang chủ</Link></Button>
      </div>
    );
  }

  const score = attempt.score;
  const gradeColor =
    score >= 8 ? "text-green-600 dark:text-green-400"
    : score >= 6.5 ? "text-primary"
    : score >= 5 ? "text-yellow-600 dark:text-yellow-400"
    : "text-red-600 dark:text-red-400";

  const totalQ = attempt.answers.length;
  const durationMin = Math.floor(attempt.durationSeconds / 60);
  const durationSec = attempt.durationSeconds % 60;

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 animate-fade-in max-w-4xl">
      {/* Score card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex flex-col items-center gap-2">
              <div className={`text-6xl font-bold ${gradeColor}`}>{score}</div>
              <div className="text-muted-foreground text-sm">/10 điểm</div>
            </div>
            <div className="flex-1 space-y-4 w-full">
              <h2 className="text-xl font-bold text-foreground">{attempt.examTitle}</h2>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="rounded-xl bg-green-50 dark:bg-green-950/40 p-3">
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">{attempt.correct}</p>
                  <p className="text-xs text-muted-foreground">Đúng</p>
                </div>
                <div className="rounded-xl bg-red-50 dark:bg-red-950/40 p-3">
                  <p className="text-2xl font-bold text-red-600 dark:text-red-400">{attempt.wrong}</p>
                  <p className="text-xs text-muted-foreground">Sai</p>
                </div>
                <div className="rounded-xl bg-muted p-3">
                  <p className="text-2xl font-bold text-foreground">{attempt.skipped}</p>
                  <p className="text-xs text-muted-foreground">Bỏ qua</p>
                </div>
              </div>
              <Progress value={(attempt.correct / totalQ) * 100} className="h-2" />
              <div className="flex gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{durationMin}:{String(durationSec).padStart(2,"0")}</span>
                <Badge variant="secondary" className={subjectColors[attempt.subject] ?? ""}>{attempt.subject}</Badge>
                <Badge variant="outline">{attempt.mode === "simulation" ? "Thi mô phỏng" : "Luyện tập"}</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-3">
        <Button asChild variant="outline"><Link to="/"><Home className="mr-2 h-4 w-4" />Trang chủ</Link></Button>
        <Button asChild variant="outline"><Link to="/thi-thu"><RotateCcw className="mr-2 h-4 w-4" />Thi lại</Link></Button>
        <Button asChild><Link to="/thong-ke"><BarChart3 className="mr-2 h-4 w-4" />Xem thống kê</Link></Button>
      </div>

      {/* Detail table */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Chi tiết từng câu</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Câu</TableHead>
                  <TableHead>Nội dung</TableHead>
                  <TableHead className="w-24">Đáp án</TableHead>
                  <TableHead className="w-20">Kết quả</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attempt.answers.map((ans, i) => {
                  const q = allQuestions.find((x) => x.id === ans.questionId);
                  if (!q) return null;
                  const ua = ans.selected;
                  const isRight = ua !== null && ua === q.correctAnswer;
                  return (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{i + 1}</TableCell>
                      <TableCell>
                        <p className="text-sm line-clamp-2">{q.text}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Đáp án đúng: <strong>{String.fromCharCode(65 + q.correctAnswer)}. {q.options[q.correctAnswer]}</strong>
                        </p>
                      </TableCell>
                      <TableCell className="text-sm">
                        {ua === null ? <span className="text-muted-foreground">Bỏ qua</span>
                          : <span>{String.fromCharCode(65 + ua)}. {q.options[ua]}</span>}
                      </TableCell>
                      <TableCell>
                        {isRight
                          ? <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"><CheckCircle2 className="mr-1 h-3 w-3" />Đúng</Badge>
                          : ua === null ? <Badge variant="secondary">Bỏ qua</Badge>
                          : <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"><XCircle className="mr-1 h-3 w-3" />Sai</Badge>}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
