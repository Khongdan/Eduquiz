import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Clock, FileText, BarChart3, Search, Shuffle, Plus, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { exams, subjects, subjectColors, difficultyColors } from "@/data/mockData";
import { apiGetExams, apiDeleteExam, apiGetAttempts } from "@/lib/api";
import type { StoredExam, ExamAttempt } from "@/lib/api";
import type { Exam } from "@/data/mockData";

export default function ExamListPage() {
  const [tab, setTab] = useState("all");
  const [search, setSearch] = useState("");
  const [filterSubject, setFilterSubject] = useState("all");
  const [customExams, setCustomExams] = useState<StoredExam[]>([]);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [custom, atts] = await Promise.all([apiGetExams(), apiGetAttempts()]);
      setCustomExams(custom);
      setAttempts(atts);
      setLoading(false);
    }
    load();
  }, []);

  const allExams: (Exam | StoredExam)[] = [...exams, ...customExams];

  const filtered = allExams.filter((e) => {
    const modeOk = tab === "all" || e.mode === tab;
    const searchOk = !search || e.title.toLowerCase().includes(search.toLowerCase());
    const subjectOk = filterSubject === "all" || e.subject === filterSubject;
    return modeOk && searchOk && subjectOk;
  });

  const getLastScore = (examId: number) => {
    const a = attempts.filter((at) => at.examId === examId).sort((a, b) => b.startedAt.localeCompare(a.startedAt))[0];
    return a?.score;
  };

  const handleDelete = async (id: number) => {
    await apiDeleteExam(id);
    setCustomExams((prev) => prev.filter((e) => e.id !== id));
  };

  const isCustom = (e: Exam | StoredExam): e is StoredExam => !!(e as StoredExam).isCustom;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-foreground">Thi thử</h1>
        <div className="flex gap-2">
          <Button variant="outline" asChild><Link to="/tao-de"><Plus className="mr-2 h-4 w-4" />Tạo đề</Link></Button>
          <Button><Shuffle className="mr-2 h-4 w-4" />Đề ngẫu nhiên</Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Tìm kiếm đề thi..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Select value={filterSubject} onValueChange={setFilterSubject}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="Môn học" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả môn</SelectItem>
            {subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">Tất cả</TabsTrigger>
            <TabsTrigger value="practice">Luyện tập</TabsTrigger>
            <TabsTrigger value="simulation">Mô phỏng</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Exam grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((exam) => {
          const lastScore = getLastScore(exam.id as number);
          return (
            <Card key={`${isCustom(exam) ? "c" : "s"}-${exam.id}`} className="card-hover flex flex-col">
              <CardContent className="p-5 flex flex-col flex-1">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="space-y-1 flex-1">
                    <h3 className="font-semibold text-foreground leading-tight line-clamp-2">{exam.title}</h3>
                    <div className="flex flex-wrap gap-1.5">
                      <Badge variant="secondary" className={subjectColors[exam.subject] ?? ""}>{exam.subject}</Badge>
                      <Badge variant="secondary" className={difficultyColors[exam.difficulty] ?? ""}>{exam.difficulty}</Badge>
                      <Badge variant={exam.mode === "simulation" ? "destructive" : "secondary"} className="text-xs">
                        {exam.mode === "simulation" ? "Mô phỏng" : "Luyện tập"}
                      </Badge>
                    </div>
                  </div>
                  {isCustom(exam) && (
                    <Button variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => handleDelete(exam.id as number)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>

                <div className="flex gap-4 text-sm text-muted-foreground mb-3">
                  <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" />{exam.questionCount} câu</span>
                  <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{exam.duration} phút</span>
                </div>

                {lastScore !== undefined && (
                  <div className="mb-3 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Lần gần nhất</span>
                      <span className={`font-semibold ${lastScore >= 8 ? "text-green-600 dark:text-green-400" : lastScore >= 5 ? "text-yellow-600 dark:text-yellow-400" : "text-red-600 dark:text-red-400"}`}>
                        {lastScore}/10
                      </span>
                    </div>
                    <Progress value={(lastScore / 10) * 100} className="h-1.5" />
                  </div>
                )}

                <div className="mt-auto flex gap-2">
                  <Button asChild className="flex-1" size="sm">
                    <Link to={`/lam-bai/${exam.id}`}>{lastScore !== undefined ? "Làm lại" : "Bắt đầu"}</Link>
                  </Button>
                  {lastScore !== undefined && (
                    <Button asChild variant="outline" size="sm">
                      <Link to="/thong-ke"><BarChart3 className="h-4 w-4" /></Link>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="h-12 w-12 mx-auto mb-3 opacity-20" />
          <p>Không tìm thấy đề thi nào</p>
        </div>
      )}
    </div>
  );
}
