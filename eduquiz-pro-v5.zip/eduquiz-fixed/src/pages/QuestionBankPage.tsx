import { useState, useEffect } from "react";
import { Search, Trash2, Plus, Filter, RotateCcw, ChevronDown, ChevronUp, Brain, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { questions as baseQuestions, subjects, subjectColors, difficultyColors } from "@/data/mockData";
import { apiGetQuestions, apiDeleteQuestion, apiGetQuestionStats, apiGetDueForReview } from "@/lib/api";
import type { StoredQuestion, QuestionStat } from "@/lib/api";
import { useNavigate } from "react-router-dom";

const PAGE_SIZE = 12;

export default function QuestionBankPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [customQuestions, setCustomQuestions] = useState<StoredQuestion[]>([]);
  const [qStats, setQStats] = useState<Record<number, QuestionStat>>({});
  const [selected, setSelected] = useState<number[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSubject, setFilterSubject] = useState("all");
  const [filterDiff, setFilterDiff] = useState("all");
  const [filterTab, setFilterTab] = useState("all");
  const [page, setPage] = useState(1);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  useEffect(() => {
    async function load() {
      const [custom, stats] = await Promise.all([apiGetQuestions(), apiGetQuestionStats()]);
      setCustomQuestions(custom);
      setQStats(stats);
      setLoading(false);
    }
    load();
  }, []);

  const allQuestions: StoredQuestion[] = [...baseQuestions as StoredQuestion[], ...customQuestions];
  const dueIds = apiGetDueForReview(allQuestions.map((q) => q.id), qStats);

  const filtered = allQuestions.filter((q) => {
    const searchOk = !searchTerm || q.text.toLowerCase().includes(searchTerm.toLowerCase()) || q.topic.toLowerCase().includes(searchTerm.toLowerCase());
    const subOk = filterSubject === "all" || q.subject === filterSubject;
    const diffOk = filterDiff === "all" || q.difficulty === filterDiff;
    const stat = qStats[q.id];
    let tabOk = true;
    if (filterTab === "unseen") tabOk = !stat || stat.attempts === 0;
    if (filterTab === "weak") tabOk = !!stat && stat.attempts > 0 && (stat.correct / stat.attempts) < 0.6;
    if (filterTab === "mastered") tabOk = !!stat && stat.attempts >= 2 && (stat.correct / stat.attempts) >= 0.8;
    if (filterTab === "due") tabOk = dueIds.includes(q.id);
    return searchOk && subOk && diffOk && tabOk;
  });

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const toggleSelect = (id: number) => {
    setSelected((prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]);
  };

  const handleDelete = async (id: number) => {
    await apiDeleteQuestion(id);
    setCustomQuestions((prev) => prev.filter((q) => q.id !== id));
  };

  const handlePracticeSelected = () => {
    if (selected.length === 0) return;
    navigate(`/lam-bai/custom?ids=${selected.join(",")}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-foreground">Ngân hàng câu hỏi</h1>
        <div className="flex gap-2">
          {selected.length > 0 && (
            <Button onClick={handlePracticeSelected}>
              <Brain className="mr-2 h-4 w-4" />Luyện {selected.length} câu đã chọn
            </Button>
          )}
          <Button variant="outline" onClick={() => navigate("/tao-de")}>
            <Plus className="mr-2 h-4 w-4" />Thêm câu hỏi
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Tìm câu hỏi, chủ đề..." className="pl-9" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
        <Select value={filterSubject} onValueChange={setFilterSubject}>
          <SelectTrigger className="w-[130px]"><SelectValue placeholder="Môn học" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả môn</SelectItem>
            {subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterDiff} onValueChange={setFilterDiff}>
          <SelectTrigger className="w-[130px]"><SelectValue placeholder="Độ khó" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tất cả</SelectItem>
            <SelectItem value="Dễ">Dễ</SelectItem>
            <SelectItem value="Trung bình">Trung bình</SelectItem>
            <SelectItem value="Khó">Khó</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs value={filterTab} onValueChange={(v) => { setFilterTab(v); setPage(1); }}>
        <TabsList>
          <TabsTrigger value="all">Tất cả ({allQuestions.length})</TabsTrigger>
          <TabsTrigger value="unseen">Chưa học</TabsTrigger>
          <TabsTrigger value="weak">Hay sai</TabsTrigger>
          <TabsTrigger value="mastered">Thành thục</TabsTrigger>
          <TabsTrigger value="due">Cần ôn ({dueIds.length})</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Question list */}
      <div className="space-y-3">
        {paginated.map((q) => {
          const stat = qStats[q.id];
          const acc = stat ? Math.round((stat.correct / stat.attempts) * 100) : null;
          const isExpanded = expandedId === q.id;
          const isCustomQ = q.isCustom;
          return (
            <Card key={q.id} className="transition-all">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Checkbox checked={selected.includes(q.id)} onCheckedChange={() => toggleSelect(q.id)} className="mt-1" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={`text-sm font-medium text-foreground ${isExpanded ? "" : "line-clamp-2"}`}>{q.text}</p>
                      <div className="flex items-center gap-1 shrink-0">
                        <button onClick={() => setExpandedId(isExpanded ? null : q.id)} className="text-muted-foreground hover:text-foreground">
                          {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        {isCustomQ && (
                          <button onClick={() => handleDelete(q.id)} className="text-muted-foreground hover:text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1.5 mt-2">
                      <Badge variant="secondary" className={`text-xs ${subjectColors[q.subject] ?? ""}`}>{q.subject}</Badge>
                      <Badge variant="secondary" className={`text-xs ${difficultyColors[q.difficulty] ?? ""}`}>{q.difficulty}</Badge>
                      <Badge variant="secondary" className="text-xs">{q.topic}</Badge>
                      {acc !== null && (
                        <Badge variant="secondary" className={`text-xs ${acc >= 80 ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" : acc >= 60 ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400" : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"}`}>
                          Đúng {acc}%
                        </Badge>
                      )}
                      {isCustomQ && <Badge variant="outline" className="text-xs">Tùy chỉnh</Badge>}
                    </div>

                    {isExpanded && (
                      <div className="mt-3 space-y-2">
                        {q.options.map((opt, i) => (
                          <div key={i} className={`flex items-center gap-2 rounded-lg p-2 text-sm ${i === q.correctAnswer ? "bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300" : "bg-muted"}`}>
                            <span className="font-bold">{String.fromCharCode(65 + i)}.</span> {opt}
                            {i === q.correctAnswer && <span className="ml-auto text-xs font-semibold">✓ Đúng</span>}
                          </div>
                        ))}
                        {q.explanation && (
                          <p className="text-xs text-muted-foreground mt-2 italic">{q.explanation}</p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Filter className="h-12 w-12 mx-auto mb-3 opacity-20" />
          <p>Không tìm thấy câu hỏi nào</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => { setSearchTerm(""); setFilterSubject("all"); setFilterDiff("all"); setFilterTab("all"); }}>
            <RotateCcw className="mr-2 h-4 w-4" />Xóa bộ lọc
          </Button>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2">
          <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}>Trước</Button>
          <span className="flex items-center text-sm text-muted-foreground px-3">{page} / {totalPages}</span>
          <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(page + 1)}>Sau</Button>
        </div>
      )}
    </div>
  );
}
