import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { BookOpen, BarChart3, FileText, Clock, ArrowRight, Trophy, Flame, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { exams as staticExams, questions as allBaseQ, subjectColors, difficultyColors } from "@/data/mockData";
import { apiGetExams, apiGetAttempts, apiGetProgress, apiGetQuestionStats, apiGetDueForReview } from "@/lib/api";
import type { StoredExam, ExamAttempt, UserProgress } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import heroImage from "@/assets/hero-education.jpg";

const features = [
  { icon: BookOpen, title: "Ngân hàng câu hỏi", desc: "Câu hỏi phân loại theo môn, chương và độ khó.", to: "/ngan-hang-cau-hoi" },
  { icon: FileText, title: "Thi thử & Luyện đề", desc: "Mô phỏng kỳ thi thật với thời gian và cấu trúc chuẩn.", to: "/thi-thu" },
  { icon: BarChart3, title: "Thống kê chi tiết", desc: "Theo dõi tiến độ, phân tích điểm mạnh và yếu.", to: "/thong-ke" },
];

export default function HomePage() {
  const { user } = useAuth();
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [progress, setProgress] = useState<UserProgress>({ totalExp: 0, level: 1, streak: 0, lastStudyDate: "", badges: [] });
  const [customExams, setCustomExams] = useState<StoredExam[]>([]);
  const [dueCount, setDueCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    Promise.all([apiGetAttempts(), apiGetProgress(), apiGetExams(), apiGetQuestionStats()])
      .then(([atts, prog, exms, stats]) => {
        setAttempts(atts);
        setProgress(prog);
        setCustomExams(exms);
        const allQIds = allBaseQ.map((q) => q.id);
        setDueCount(apiGetDueForReview(allQIds, stats).length);
      });
  }, [user]);

  const allExams = [...staticExams, ...customExams];
  const totalAttempts = attempts.length;
  const avgScore = totalAttempts
    ? (attempts.reduce((s, a) => s + a.score, 0) / totalAttempts).toFixed(1)
    : null;

  const recentExams = allExams.slice(0, 5);

  const stats = [
    { icon: FileText,  label: "Tổng đề thi",    value: String(allExams.length) },
    { icon: BookOpen,  label: "Bài đã làm",      value: String(totalAttempts) },
    { icon: BarChart3, label: "Điểm trung bình", value: avgScore ?? "—" },
    { icon: Flame,     label: "Streak",          value: `${progress.streak} ngày` },
  ];

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5 py-16 lg:py-24">
        <div className="container mx-auto px-4 flex flex-col lg:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            {user && (
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <Trophy className="h-4 w-4" />
                Xin chào, {user.name.split(" ").pop()}! · Level {progress.level}
              </div>
            )}
            <h1 className="text-4xl lg:text-5xl font-bold leading-tight text-foreground">
              Luyện thi thông minh –{" "}
              <span className="text-primary">Học hiệu quả hơn</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-xl">
              Nền tảng luyện thi với hệ thống câu hỏi phong phú, đề thi mô phỏng và
              thống kê chi tiết giúp bạn tự tin chinh phục mọi kỳ thi.
            </p>
            {user && (
              <div className="max-w-sm space-y-1.5">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Level {progress.level}</span>
                  <span>{progress.totalExp} / {progress.level * 200} EXP</span>
                </div>
                <Progress value={(progress.totalExp / (progress.level * 200)) * 100} className="h-2" />
              </div>
            )}
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg" className="font-semibold">
                <Link to="/thi-thu">Bắt đầu luyện tập</Link>
              </Button>
              {dueCount > 0 && (
                <Button asChild size="lg" variant="outline">
                  <Link to="/ngan-hang-cau-hoi">
                    <Brain className="mr-2 h-4 w-4 text-orange-500" />
                    Ôn {dueCount} câu hôm nay
                  </Link>
                </Button>
              )}
            </div>
          </div>
          <div className="flex-1 max-w-lg">
            <img src={heroImage} alt="Học tập trực tuyến" className="rounded-2xl shadow-lg" />
          </div>
        </div>
      </section>

      {/* Stats thật */}
      <section className="container mx-auto px-4 -mt-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <Card key={s.label} className="card-hover">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <s.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{s.value}</p>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center mb-8 text-foreground">Tính năng nổi bật</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {features.map((f) => (
            <Link key={f.title} to={f.to}>
              <Card className="card-hover text-center h-full">
                <CardContent className="p-6 space-y-4">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                    <f.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{f.title}</h3>
                  <p className="text-sm text-muted-foreground">{f.desc}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Đề thi gần đây */}
      <section className="container mx-auto px-4 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-foreground">Đề thi gần đây</h2>
          <Button variant="ghost" asChild>
            <Link to="/thi-thu">Xem tất cả <ArrowRight className="ml-1 h-4 w-4" /></Link>
          </Button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
          {recentExams.map((exam) => {
            const lastAttempt = attempts
              .filter((a) => a.examId === exam.id)
              .sort((a, b) => b.startedAt.localeCompare(a.startedAt))[0];
            return (
              <Card key={exam.id} className="card-hover min-w-[280px] shrink-0 snap-start">
                <CardContent className="p-4 space-y-3">
                  <h4 className="font-semibold text-foreground line-clamp-1">{exam.title}</h4>
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="secondary" className={subjectColors[exam.subject]}>{exam.subject}</Badge>
                    <Badge variant="secondary" className={difficultyColors[exam.difficulty]}>{exam.difficulty}</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{exam.duration} phút</span>
                    <span className="flex items-center gap-1"><FileText className="h-3.5 w-3.5" />{exam.questionCount} câu</span>
                  </div>
                  {lastAttempt && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Lần trước</span>
                        <span className={`font-semibold ${lastAttempt.score >= 8 ? "text-green-600 dark:text-green-400" : lastAttempt.score >= 5 ? "text-yellow-600 dark:text-yellow-400" : "text-red-600 dark:text-red-400"}`}>
                          {lastAttempt.score}/10
                        </span>
                      </div>
                      <Progress value={lastAttempt.score * 10} className="h-1.5" />
                    </div>
                  )}
                  <Button className="w-full" size="sm" asChild>
                    <Link to={`/lam-bai/${exam.id}`}>{lastAttempt ? "Làm lại" : "Bắt đầu"}</Link>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
}
