import { useState, useEffect } from "react";
import { BookOpen, BarChart3, Flame, Clock, ArrowRight, Trophy, Star, Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";
import { scoreOverTime, accuracyBySubject, weakTopics, subjectColors } from "@/data/mockData";
import { apiGetAttempts, apiGetProgress, apiGetQuestionStats, BADGE_CATALOG } from "@/lib/api";
import type { ExamAttempt, UserProgress, QuestionStat } from "@/lib/api";
import { Link } from "react-router-dom";

const COLORS = ["hsl(239, 84%, 67%)", "hsl(270, 70%, 60%)", "hsl(25, 95%, 53%)", "hsl(187, 92%, 42%)"];

export default function StatisticsPage() {
  const [range, setRange] = useState("30");
  const [loading, setLoading] = useState(true);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [progress, setProgress] = useState<UserProgress>({ totalExp: 0, level: 1, streak: 0, lastStudyDate: "", badges: [] });
  const [qStats, setQStats] = useState<Record<number, QuestionStat>>({});

  useEffect(() => {
    async function load() {
      const [atts, prog, stats] = await Promise.all([
        apiGetAttempts(),
        apiGetProgress(),
        apiGetQuestionStats(),
      ]);
      setAttempts(atts);
      setProgress(prog);
      setQStats(stats);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const totalAttempts = attempts.length;
  const avgScore = totalAttempts
    ? (attempts.reduce((s, a) => s + a.score, 0) / totalAttempts).toFixed(1)
    : "—";
  const totalTime = attempts.reduce((s, a) => s + a.durationSeconds, 0);
  const totalTimeStr = `${Math.floor(totalTime / 3600)}h ${Math.floor((totalTime % 3600) / 60)}m`;

  const recentHistory = attempts.slice(0, 8).map((a) => ({
    date: new Date(a.startedAt).toLocaleDateString("vi-VN"),
    exam: a.examTitle,
    subject: a.subject,
    score: a.score,
    time: `${Math.floor(a.durationSeconds / 60)}:${(a.durationSeconds % 60).toString().padStart(2, "0")}`,
    mode: a.mode === "simulation" ? "Thi mô phỏng" : "Luyện tập",
  }));

  const worstQuestions = Object.values(qStats)
    .filter((s) => s.attempts >= 2)
    .sort((a, b) => (a.correct / a.attempts) - (b.correct / b.attempts))
    .slice(0, 5);

  const summaryCards = [
    { icon: BookOpen, label: "Tổng bài đã làm", value: String(totalAttempts) },
    { icon: BarChart3, label: "Điểm trung bình", value: String(avgScore) },
    { icon: Flame, label: "Streak hiện tại", value: `${progress.streak} ngày` },
    { icon: Clock, label: "Thời gian học", value: totalTimeStr },
  ];

  const EmptyChart = ({ msg }: { msg: string }) => (
    <div className="flex flex-col items-center justify-center h-[280px] text-muted-foreground space-y-3">
      <BarChart3 className="h-10 w-10 opacity-20" />
      <p className="text-sm">{msg}</p>
      <Button size="sm" asChild variant="outline"><Link to="/thi-thu">Bắt đầu ngay</Link></Button>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-6 space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold text-foreground">Thống kê học tập</h1>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((s) => (
          <Card key={s.label} className="card-hover">
            <CardContent className="flex items-center gap-3 p-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <s.icon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Level & Badges */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <Trophy className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-foreground">Cấp độ & Kinh nghiệm</h3>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-primary">Level {progress.level}</span>
                <span className="text-sm text-muted-foreground">{progress.totalExp} / {progress.level * 200} EXP</span>
              </div>
              <Progress value={(progress.totalExp / (progress.level * 200)) * 100} className="h-3" />
              <p className="text-sm text-muted-foreground">🔥 Streak {progress.streak} ngày liên tiếp</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-4">
              <Star className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-foreground">Huy hiệu đạt được ({progress.badges.length})</h3>
            </div>
            {progress.badges.length === 0 ? (
              <p className="text-sm text-muted-foreground">Hãy hoàn thành bài thi để nhận huy hiệu!</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {progress.badges.map((bid) => {
                  const b = BADGE_CATALOG[bid];
                  return b ? (
                    <div key={bid} className="flex items-center gap-1.5 rounded-xl bg-muted px-3 py-2" title={b.desc}>
                      <span className="text-xl">{b.icon}</span>
                      <div>
                        <p className="text-xs font-semibold">{b.label}</p>
                        <p className="text-xs text-muted-foreground">{b.desc}</p>
                      </div>
                    </div>
                  ) : null;
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-foreground">Điểm theo thời gian</h3>
              <Tabs value={range} onValueChange={setRange}>
                <TabsList className="h-8">
                  <TabsTrigger value="7" className="text-xs px-2 h-6">7 ngày</TabsTrigger>
                  <TabsTrigger value="30" className="text-xs px-2 h-6">30 ngày</TabsTrigger>
                  <TabsTrigger value="90" className="text-xs px-2 h-6">3 tháng</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            {totalAttempts === 0 ? (
              <EmptyChart msg="Chưa có dữ liệu — hãy hoàn thành bài thi đầu tiên!" />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <LineChart data={scoreOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                  <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  {["Toán", "Vật lý", "Hóa học", "Tiếng Anh"].map((s, i) => (
                    <Line key={s} type="monotone" dataKey={s} stroke={COLORS[i]} strokeWidth={2} dot={{ r: 3 }} />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Tỉ lệ đúng theo môn</h3>
            {totalAttempts === 0 ? (
              <EmptyChart msg="Hoàn thành bài thi để xem tỉ lệ đúng theo môn!" />
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={accuracyBySubject} layout="vertical" margin={{ left: 60 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} />
                  <YAxis type="category" dataKey="subject" tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(v: number) => `${v}%`} />
                  <Bar dataKey="accuracy" radius={[0, 6, 6, 0]} maxBarSize={20}>
                    {accuracyBySubject.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent History */}
      {recentHistory.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Lịch sử gần đây</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ngày</TableHead>
                    <TableHead>Tên bài thi</TableHead>
                    <TableHead>Môn</TableHead>
                    <TableHead>Điểm</TableHead>
                    <TableHead>Thời gian</TableHead>
                    <TableHead>Chế độ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentHistory.map((h, i) => (
                    <TableRow key={i}>
                      <TableCell className="text-sm">{h.date}</TableCell>
                      <TableCell className="text-sm font-medium">{h.exam}</TableCell>
                      <TableCell><Badge variant="secondary" className={subjectColors[h.subject] ?? ""}>{h.subject}</Badge></TableCell>
                      <TableCell>
                        <span className={`font-semibold ${h.score >= 8 ? "text-green-600 dark:text-green-400" : h.score >= 5 ? "text-yellow-600 dark:text-yellow-400" : "text-red-600 dark:text-red-400"}`}>
                          {h.score}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm">{h.time}</TableCell>
                      <TableCell><Badge variant="outline">{h.mode}</Badge></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Spaced Repetition */}
      {worstQuestions.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">Câu hỏi hay sai nhất (Spaced Repetition)</h3>
            <div className="space-y-3">
              {worstQuestions.map((s) => (
                <div key={s.questionId} className="flex items-center justify-between rounded-xl border border-border p-4">
                  <div>
                    <p className="font-medium text-foreground text-sm">Câu #{s.questionId}</p>
                    <p className="text-sm text-muted-foreground">
                      Đúng: <span className="text-destructive font-medium">{Math.round((s.correct / s.attempts) * 100)}%</span>
                      &nbsp;·&nbsp;{s.attempts} lần làm
                      &nbsp;·&nbsp;Ôn tiếp: {new Date(s.nextReview).toLocaleDateString("vi-VN")}
                    </p>
                  </div>
                  <Badge variant="secondary" className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400">Cần ôn</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weak Topics */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Chủ đề cần ôn lại</h3>
          <div className="space-y-3">
            {weakTopics.map((t) => (
              <div key={t.topic} className="flex items-center justify-between rounded-xl border border-border p-4">
                <div>
                  <p className="font-medium text-foreground">{t.topic}</p>
                  <p className="text-sm text-muted-foreground">{t.subject} · {t.questionCount} câu · Tỉ lệ đúng: <span className="text-destructive font-medium">{t.accuracy}%</span></p>
                </div>
                <Button size="sm" asChild><Link to="/ngan-hang-cau-hoi">Luyện ngay <ArrowRight className="ml-1 h-3 w-3" /></Link></Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
