import { useState } from "react";
import { Navigate } from "react-router-dom";
import { GraduationCap, Mail, Lock, User, Eye, EyeOff, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";

export default function AuthPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  if (user) { navigate("/", { replace: true }); return null; }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 px-4 py-8">
      <Card className="w-full max-w-md animate-fade-in">
        <CardContent className="p-6 space-y-6">
          <div className="text-center space-y-2">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
              <GraduationCap className="h-7 w-7 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">EduQuiz Pro</h1>
            <p className="text-sm text-muted-foreground">Nền tảng luyện thi thông minh</p>
          </div>
          <Tabs defaultValue="login">
            <TabsList className="w-full">
              <TabsTrigger value="login" className="flex-1">Đăng nhập</TabsTrigger>
              <TabsTrigger value="register" className="flex-1">Đăng ký</TabsTrigger>
            </TabsList>
            <TabsContent value="login"><LoginForm onSuccess={() => navigate("/")} /></TabsContent>
            <TabsContent value="register"><RegisterForm onSuccess={() => navigate("/")} /></TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

function ErrorBox({ msg }: { msg: string }) {
  return (
    <div className="flex items-center gap-2 rounded-lg bg-destructive/10 border border-destructive/20 px-3 py-2 text-sm text-destructive">
      <AlertCircle className="h-4 w-4 shrink-0" />{msg}
    </div>
  );
}

function LoginForm({ onSuccess }: { onSuccess: () => void }) {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) { setError("Vui lòng điền đầy đủ thông tin"); return; }
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.ok) onSuccess();
    else setError(result.error ?? "Đăng nhập thất bại");
  };

  return (
    <form className="space-y-4 mt-4" onSubmit={handleSubmit}>
      {error && <ErrorBox msg={error} />}
      <div className="space-y-2">
        <Label>Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="email@example.com" className="pl-9" value={email}
            onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Mật khẩu</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input type={showPw ? "text" : "password"} placeholder="••••••••" className="pl-9 pr-9"
            value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
          <button type="button" onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>
      <Button className="w-full" type="submit" disabled={loading}>
        {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Đang đăng nhập...</> : "Đăng nhập"}
      </Button>
      <p className="text-xs text-center text-muted-foreground">
        Chưa có tài khoản? Chuyển sang tab <strong>Đăng ký</strong> để tạo mới.
      </p>
    </form>
  );
}

function RegisterForm({ onSuccess }: { onSuccess: () => void }) {
  const { register } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) { setError("Mật khẩu xác nhận không khớp"); return; }
    setLoading(true);
    const result = await register(name, email, password);
    setLoading(false);
    if (result.ok) onSuccess();
    else setError(result.error ?? "Đăng ký thất bại");
  };

  return (
    <form className="space-y-4 mt-4" onSubmit={handleSubmit}>
      {error && <ErrorBox msg={error} />}
      <div className="space-y-2">
        <Label>Họ tên</Label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Nguyễn Văn An" className="pl-9" value={name}
            onChange={(e) => setName(e.target.value)} autoComplete="name" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Email</Label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="email@example.com" className="pl-9" value={email}
            onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Mật khẩu <span className="text-muted-foreground text-xs">(tối thiểu 6 ký tự)</span></Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input type={showPw ? "text" : "password"} placeholder="••••••••" className="pl-9 pr-9"
            value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
          <button type="button" onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>
      <div className="space-y-2">
        <Label>Xác nhận mật khẩu</Label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input type={showPw ? "text" : "password"} placeholder="••••••••" className="pl-9"
            value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
        </div>
      </div>
      <Button className="w-full" type="submit" disabled={loading}>
        {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Đang tạo tài khoản...</> : "Tạo tài khoản"}
      </Button>
    </form>
  );
}
