import { Link, useLocation, useNavigate } from "react-router-dom";
import { Bell, ChevronDown, GraduationCap, Menu, User, LogOut, Sun, Moon, Trophy } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/hooks/useAuth";
import { getProgress } from "@/lib/store";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const navLinks = [
  { to: "/", label: "Trang chủ" },
  { to: "/ngan-hang-cau-hoi", label: "Ngân hàng" },
  { to: "/thi-thu", label: "Thi thử" },
  { to: "/thong-ke", label: "Thống kê" },
];

export function Navbar({ onToggleSidebar }: { onToggleSidebar?: () => void }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const { user, logout } = useAuth();
  const progress = getProgress();

  const handleLogout = () => {
    logout();
    navigate("/dang-nhap", { replace: true });
  };

  // Avatar initials + color
  const initials = user?.name
    ? user.name.split(" ").slice(-2).map((w) => w[0]).join("").toUpperCase()
    : "?";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="flex h-full items-center justify-between px-4 lg:px-6">
        {/* Logo */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={onToggleSidebar}>
              <Menu className="h-5 w-5" />
            </Button>
          )}
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <GraduationCap className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold text-foreground hidden sm:inline">EduQuiz Pro</span>
          </Link>
        </div>

        {/* Nav links */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link key={link.to} to={link.to}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                location.pathname === link.to
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              }`}>
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-2">
          {/* Level badge */}
          {user && (
            <div className="hidden sm:flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
              <Trophy className="h-3 w-3" />
              Lv.{progress.level}
              {progress.streak > 0 && (
                <span className="ml-1 text-orange-500">🔥{progress.streak}</span>
              )}
            </div>
          )}

          {/* Dark mode toggle – pill style */}
          <div className="flex items-center rounded-full border border-border bg-muted p-1 gap-0.5">
            <button
              onClick={() => setTheme("light")}
              title="Chế độ sáng"
              className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium transition-all duration-200 ${
                theme === "light"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Sun className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Sáng</span>
            </button>
            <button
              onClick={() => setTheme("dark")}
              title="Chế độ tối"
              className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium transition-all duration-200 ${
                theme === "dark"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Moon className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Tối</span>
            </button>
          </div>

          {/* User menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 px-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full text-white text-sm font-bold"
                    style={{ backgroundColor: user.avatarColor }}>
                    {initials}
                  </div>
                  <span className="hidden sm:inline text-sm font-medium max-w-[120px] truncate">{user.name}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <div className="px-3 py-2 border-b border-border">
                  <p className="text-sm font-semibold text-foreground truncate">{user.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                </div>
                <DropdownMenuItem asChild className="mt-1">
                  <Link to="/thong-ke"><Trophy className="mr-2 h-4 w-4" />Level {progress.level} · {progress.streak} ngày streak</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />Đăng xuất
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button size="sm" asChild><Link to="/dang-nhap">Đăng nhập</Link></Button>
          )}
        </div>
      </div>
    </header>
  );
}
