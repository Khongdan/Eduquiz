@echo off
echo ============================================
echo  EduQuiz Pro - Cai dat Backend
echo ============================================
echo.

REM Kiem tra file .env ton tai chua
IF NOT EXIST ".env" (
    echo [1/3] Tao file .env tu .env.example...
    copy .env.example .env
    echo.
    echo *** QUAN TRONG: Mo file .env va doi YOUR_PASSWORD ***
    echo     Dung Notepad: notepad .env
    echo.
    pause
)

echo [2/3] Cai dat thu vien Node.js...
call npm install
if %errorlevel% neq 0 (
    echo LOI: npm install that bai. Hay cai Node.js truoc.
    pause
    exit /b 1
)

echo.
echo [3/3] Chay server...
echo.
echo Server se chay tai: http://localhost:3001
echo Health check:       http://localhost:3001/api/health
echo.
echo Nhan Ctrl+C de dung server.
echo.
call npm run dev
