const router = require("express").Router();
const db = require("../db");
const auth = require("../middleware/auth");

// GET /api/exams
router.get("/", auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT * FROM exams WHERE user_id = $1 ORDER BY created_at DESC",
      [req.userId]
    );
    res.json(rows.map(toExam));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// POST /api/exams
router.post("/", auth, async (req, res) => {
  const e = req.body;
  try {
    const { rows } = await db.query(
      `INSERT INTO exams (user_id, title, subject, difficulty, question_count, duration, mode, question_ids, is_custom)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [req.userId, e.title, e.subject, e.difficulty || "Trung bình",
       e.questionCount, e.duration || 45, e.mode || "practice",
       JSON.stringify(e.questionIds || []), true]
    );
    res.json(toExam(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// DELETE /api/exams/:id
router.delete("/:id", auth, async (req, res) => {
  try {
    await db.query("DELETE FROM exams WHERE id = $1 AND user_id = $2", [req.params.id, req.userId]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

function toExam(row) {
  return {
    id: row.id,
    title: row.title,
    subject: row.subject,
    difficulty: row.difficulty,
    questionCount: row.question_count,
    duration: row.duration,
    mode: row.mode,
    questionIds: row.question_ids,
    isCustom: row.is_custom,
    attempted: false,
    year: new Date(row.created_at).getFullYear(),
    createdAt: row.created_at,
  };
}

module.exports = router;
