const router = require("express").Router();
const db = require("../db");
const auth = require("../middleware/auth");

// GET /api/questions – lấy câu hỏi custom của user
router.get("/", auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT * FROM questions WHERE user_id = $1 ORDER BY created_at DESC",
      [req.userId]
    );
    res.json(rows.map(toQuestion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// POST /api/questions – lưu câu hỏi mới
router.post("/", auth, async (req, res) => {
  const q = req.body;
  try {
    const { rows } = await db.query(
      `INSERT INTO questions (user_id, text, options, correct_answer, subject, difficulty, topic, year, explanation, is_custom)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [req.userId, q.text, JSON.stringify(q.options), q.correctAnswer, q.subject,
       q.difficulty || "Trung bình", q.topic || "Import", q.year || new Date().getFullYear(),
       q.explanation || "", true]
    );
    res.json(toQuestion(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// DELETE /api/questions/:id
router.delete("/:id", auth, async (req, res) => {
  try {
    await db.query("DELETE FROM questions WHERE id = $1 AND user_id = $2", [req.params.id, req.userId]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

function toQuestion(row) {
  return {
    id: row.id,
    text: row.text,
    options: row.options,
    correctAnswer: row.correct_answer,
    subject: row.subject,
    difficulty: row.difficulty,
    topic: row.topic,
    year: row.year,
    explanation: row.explanation,
    isCustom: row.is_custom,
    createdAt: row.created_at,
  };
}

module.exports = router;
