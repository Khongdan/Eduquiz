const router = require("express").Router();
const db = require("../db");
const auth = require("../middleware/auth");

// GET /api/attempts
router.get("/", auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT * FROM attempts WHERE user_id = $1 ORDER BY finished_at DESC",
      [req.userId]
    );
    res.json(rows.map(toAttempt));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// GET /api/attempts/:id
router.get("/:id", auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT * FROM attempts WHERE id = $1 AND user_id = $2",
      [req.params.id, req.userId]
    );
    if (rows.length === 0) return res.status(404).json({ error: "Không tìm thấy" });
    res.json(toAttempt(rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// POST /api/attempts
router.post("/", auth, async (req, res) => {
  const a = req.body;
  const client = await db.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `INSERT INTO attempts (id, user_id, exam_id, exam_title, subject, started_at, finished_at,
        duration_seconds, answers, score, correct, wrong, skipped, mode)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       ON CONFLICT (id) DO NOTHING`,
      [a.id, req.userId, a.examId, a.examTitle, a.subject,
       a.startedAt, a.finishedAt, a.durationSeconds,
       JSON.stringify(a.answers), a.score, a.correct, a.wrong, a.skipped, a.mode]
    );

    // Cập nhật progress
    await updateProgress(client, req.userId, a);

    await client.query("COMMIT");
    res.json({ ok: true });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  } finally {
    client.release();
  }
});

async function updateProgress(client, userId, attempt) {
  // Lấy progress hiện tại
  let { rows } = await client.query("SELECT * FROM user_progress WHERE user_id = $1", [userId]);
  if (rows.length === 0) {
    await client.query("INSERT INTO user_progress (user_id) VALUES ($1)", [userId]);
    rows = (await client.query("SELECT * FROM user_progress WHERE user_id = $1", [userId])).rows;
  }
  let prog = rows[0];

  // EXP
  const gained = attempt.correct * 10 + Math.floor(attempt.score * 5);
  let exp = prog.total_exp + gained;
  let level = prog.level;
  while (exp >= level * 200 && level < 10) { exp -= level * 200; level++; }

  // Streak
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  let streak = prog.streak;
  const lastDate = prog.last_study_date ? prog.last_study_date.toISOString?.()?.slice(0,10) ?? String(prog.last_study_date).slice(0,10) : null;
  if (lastDate !== today) {
    streak = lastDate === yesterday ? streak + 1 : 1;
  }

  // Badges
  const { rows: allAttempts } = await client.query(
    "SELECT correct FROM attempts WHERE user_id = $1", [userId]
  );
  const totalCorrect = allAttempts.reduce((s, r) => s + r.correct, 0);
  let badges = Array.isArray(prog.badges) ? [...prog.badges] : JSON.parse(prog.badges || "[]");
  const earn = (id) => { if (!badges.includes(id)) badges.push(id); };
  if (totalCorrect >= 10) earn("first_10");
  if (totalCorrect >= 50) earn("fifty_correct");
  if (totalCorrect >= 100) earn("hundred_correct");
  if (streak >= 3) earn("streak_3");
  if (streak >= 7) earn("streak_7");
  if (attempt.score >= 9) earn("score_9");
  if (attempt.wrong === 0 && attempt.skipped === 0) earn("perfect");

  await client.query(
    `UPDATE user_progress SET total_exp=$1, level=$2, streak=$3, last_study_date=$4, badges=$5
     WHERE user_id=$6`,
    [exp, level, streak, today, JSON.stringify(badges), userId]
  );
}

function toAttempt(row) {
  return {
    id: row.id,
    examId: row.exam_id,
    examTitle: row.exam_title,
    subject: row.subject,
    startedAt: row.started_at,
    finishedAt: row.finished_at,
    durationSeconds: row.duration_seconds,
    answers: row.answers,
    score: parseFloat(row.score),
    correct: row.correct,
    wrong: row.wrong,
    skipped: row.skipped,
    mode: row.mode,
  };
}

module.exports = router;
