const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");

const COLORS = ["#6366f1","#0ea5e9","#10b981","#f59e0b","#ef4444","#8b5cf6","#ec4899"];

function makeToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "30d" });
}

// POST /api/auth/register
router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: "Vui lòng nhập họ tên" });
  if (!email?.includes("@")) return res.status(400).json({ error: "Email không hợp lệ" });
  if (!password || password.length < 6) return res.status(400).json({ error: "Mật khẩu tối thiểu 6 ký tự" });

  try {
    const existing = await db.query("SELECT id FROM users WHERE email = $1", [email.toLowerCase()]);
    if (existing.rows.length > 0) return res.status(409).json({ error: "Email này đã được đăng ký" });

    const count = (await db.query("SELECT COUNT(*) FROM users")).rows[0].count;
    const avatarColor = COLORS[Number(count) % COLORS.length];
    const passwordHash = await bcrypt.hash(password, 10);

    const { rows } = await db.query(
      "INSERT INTO users (name, email, password_hash, avatar_color) VALUES ($1,$2,$3,$4) RETURNING id, name, email, avatar_color",
      [name.trim(), email.toLowerCase(), passwordHash, avatarColor]
    );
    const user = rows[0];

    // Tạo bản ghi progress mặc định
    await db.query("INSERT INTO user_progress (user_id) VALUES ($1) ON CONFLICT DO NOTHING", [user.id]);

    res.json({
      token: makeToken(user.id),
      user: { name: user.name, email: user.email, avatarColor: user.avatar_color },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// POST /api/auth/login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Thiếu email hoặc mật khẩu" });

  try {
    const { rows } = await db.query("SELECT * FROM users WHERE email = $1", [email.toLowerCase()]);
    if (rows.length === 0) return res.status(401).json({ error: "Email hoặc mật khẩu không đúng" });

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: "Email hoặc mật khẩu không đúng" });

    // Đảm bảo có progress
    await db.query("INSERT INTO user_progress (user_id) VALUES ($1) ON CONFLICT DO NOTHING", [user.id]);

    res.json({
      token: makeToken(user.id),
      user: { name: user.name, email: user.email, avatarColor: user.avatar_color },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

module.exports = router;
