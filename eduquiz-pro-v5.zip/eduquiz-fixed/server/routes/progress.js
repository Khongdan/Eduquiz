const router = require("express").Router();
const db = require("../db");
const auth = require("../middleware/auth");

// GET /api/progress
router.get("/", auth, async (req, res) => {
  try {
    await db.query("INSERT INTO user_progress (user_id) VALUES ($1) ON CONFLICT DO NOTHING", [req.userId]);
    const { rows } = await db.query("SELECT * FROM user_progress WHERE user_id = $1", [req.userId]);
    const p = rows[0];
    res.json({
      totalExp: p.total_exp,
      level: p.level,
      streak: p.streak,
      lastStudyDate: p.last_study_date || "",
      badges: Array.isArray(p.badges) ? p.badges : JSON.parse(p.badges || "[]"),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// GET /api/stats  – question stats
router.get("/stats", auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      "SELECT * FROM question_stats WHERE user_id = $1",
      [req.userId]
    );
    const result = {};
    rows.forEach((r) => {
      result[r.question_id] = {
        questionId: r.question_id,
        attempts: r.attempts,
        correct: r.correct,
        lastSeen: r.last_seen,
        nextReview: r.next_review,
        easeFactor: parseFloat(r.ease_factor),
        interval: r.interval,
      };
    });
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

// POST /api/progress/stats – cập nhật question stat (SM-2)
router.post("/stats", auth, async (req, res) => {
  const { questionId, wasCorrect } = req.body;
  try {
    const today = new Date().toISOString();
    // Upsert
    let { rows } = await db.query(
      "SELECT * FROM question_stats WHERE user_id=$1 AND question_id=$2",
      [req.userId, questionId]
    );

    let stat = rows[0] ?? {
      attempts: 0, correct: 0, ease_factor: 2.5, interval: 1,
    };

    stat.attempts += 1;
    if (wasCorrect) stat.correct += 1;

    // SM-2
    const grade = wasCorrect ? 4 : 1;
    if (grade >= 3) {
      if (stat.interval === 1) stat.interval = 1;
      else if (stat.interval === 2) stat.interval = 6;
      else stat.interval = Math.round(stat.interval * stat.ease_factor);
      stat.ease_factor = Math.max(1.3, stat.ease_factor + 0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02));
    } else {
      stat.interval = 1;
      stat.ease_factor = Math.max(1.3, stat.ease_factor - 0.2);
    }

    const next = new Date();
    next.setDate(next.getDate() + stat.interval);

    await db.query(
      `INSERT INTO question_stats (user_id, question_id, attempts, correct, last_seen, next_review, ease_factor, interval)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (user_id, question_id) DO UPDATE SET
         attempts=$3, correct=$4, last_seen=$5, next_review=$6, ease_factor=$7, interval=$8`,
      [req.userId, questionId, stat.attempts, stat.correct,
       today, next.toISOString(), stat.ease_factor, stat.interval]
    );

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi server" });
  }
});

module.exports = router;
