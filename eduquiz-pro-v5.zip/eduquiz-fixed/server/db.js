const { Pool } = require("pg");
require("dotenv").config();

if (!process.env.DATABASE_URL) {
  console.error("❌ LỖI: DATABASE_URL chưa được cấu hình trong file server/.env");
  console.error("   Hãy sao chép .env.example thành .env và điền thông tin database.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
});

pool.on("error", (err) => {
  console.error("❌ Lỗi PostgreSQL không mong muốn:", err.message);
});

// Test kết nối ngay khi khởi động
pool.query("SELECT 1").then(() => {
  console.log("✅ Kết nối PostgreSQL thành công");
}).catch((err) => {
  console.error("❌ Không thể kết nối PostgreSQL:", err.message);
  console.error("   Kiểm tra DATABASE_URL trong file server/.env");
});

module.exports = pool;
