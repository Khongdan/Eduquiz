@echo off
echo ============================================
echo  EduQuiz Pro - Khoi tao Bang PostgreSQL
echo ============================================
echo.

REM Doc DATABASE_URL tu .env
IF NOT EXIST ".env" (
    echo LOI: Chua co file .env. Chay setup.bat truoc.
    pause
    exit /b 1
)

REM Lay password tu DATABASE_URL trong .env
for /f "tokens=2 delims==" %%a in ('findstr "DATABASE_URL" .env') do set DB_URL=%%a

echo Dang khoi tao bang tu schema.sql...
echo (Se hoi mat khau PostgreSQL neu can)
echo.

psql "%DB_URL%" -f schema.sql

if %errorlevel% neq 0 (
    echo.
    echo LOI: Khong the chay schema.sql
    echo - Kiem tra PostgreSQL da chay chua
    echo - Kiem tra DATABASE_URL trong file .env
    echo - Kiem tra password trong DATABASE_URL co dung khong
) else (
    echo.
    echo ✓ Khoi tao database thanh cong!
    echo   Co the chay server bang: setup.bat
)

echo.
pause
