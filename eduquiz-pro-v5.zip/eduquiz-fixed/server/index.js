require("dotenv").config();
const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();

// Cho phép tất cả localhost port trong dev, production dùng FRONTEND_URL
const allowedOrigins = process.env.FRONTEND_URL
  ? [process.env.FRONTEND_URL]
  : [/^http:\/\/localhost:\d+$/, /^http:\/\/127\.0\.0\.1:\d+$/];

app.use(cors({
  origin: allowedOrigins,
  credentials: true,
}));
app.use(express.json());

// Routes
app.use("/api/auth",      require("./routes/auth"));
app.use("/api/questions", require("./routes/questions"));
app.use("/api/exams",     require("./routes/exams"));
app.use("/api/attempts",  require("./routes/attempts"));
app.use("/api/progress",  require("./routes/progress"));

// Health check
app.get("/api/health", async (req, res) => {
  try {
    await db.query("SELECT 1");
    res.json({ status: "ok", db: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", db: "disconnected", detail: err.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n✅ EduQuiz server chạy tại http://localhost:${PORT}`);
  console.log(`   Health check: http://localhost:${PORT}/api/health`);
  const dbUrl = process.env.DATABASE_URL?.replace(/:([^:@]+)@/, ":***@") ?? "CHƯA CẤU HÌNH";
  console.log(`   Database: ${dbUrl}`);
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET === "change_this_to_a_long_random_string_in_production") {
    console.warn("\n⚠️  CẢNH BÁO: JWT_SECRET chưa được đặt trong file .env!\n");
  }
});
