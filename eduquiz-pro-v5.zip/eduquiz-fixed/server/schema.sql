-- EduQuiz Pro – PostgreSQL Schema
-- Chạy: psql -U postgres -d eduquiz -f schema.sql

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(255)        NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255)        NOT NULL,
  avatar_color  VARCHAR(20)         NOT NULL DEFAULT '#6366f1',
  created_at    TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS questions (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER REFERENCES users(id) ON DELETE CASCADE,
  text           TEXT    NOT NULL,
  options        JSONB   NOT NULL,
  correct_answer INTEGER NOT NULL,
  subject        VARCHAR(100) DEFAULT 'Khác',
  difficulty     VARCHAR(50)  DEFAULT 'Trung bình',
  topic          VARCHAR(100) DEFAULT 'Import',
  year           INTEGER,
  explanation    TEXT,
  is_custom      BOOLEAN      DEFAULT TRUE,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exams (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER REFERENCES users(id) ON DELETE CASCADE,
  title          VARCHAR(255) NOT NULL,
  subject        VARCHAR(100),
  difficulty     VARCHAR(50)  DEFAULT 'Trung bình',
  question_count INTEGER,
  duration       INTEGER      DEFAULT 45,
  mode           VARCHAR(20)  DEFAULT 'practice',
  question_ids   JSONB        DEFAULT '[]',
  is_custom      BOOLEAN      DEFAULT TRUE,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attempts (
  id               VARCHAR(50) PRIMARY KEY,
  user_id          INTEGER REFERENCES users(id) ON DELETE CASCADE,
  exam_id          INTEGER,
  exam_title       VARCHAR(255),
  subject          VARCHAR(100),
  started_at       TIMESTAMPTZ,
  finished_at      TIMESTAMPTZ,
  duration_seconds INTEGER,
  answers          JSONB   DEFAULT '[]',
  score            NUMERIC(4,1),
  correct          INTEGER DEFAULT 0,
  wrong            INTEGER DEFAULT 0,
  skipped          INTEGER DEFAULT 0,
  mode             VARCHAR(20),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS question_stats (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES users(id) ON DELETE CASCADE,
  question_id INTEGER NOT NULL,
  attempts    INTEGER     DEFAULT 0,
  correct     INTEGER     DEFAULT 0,
  last_seen   TIMESTAMPTZ,
  next_review TIMESTAMPTZ,
  ease_factor NUMERIC(4,2) DEFAULT 2.5,
  interval    INTEGER      DEFAULT 1,
  UNIQUE (user_id, question_id)
);

CREATE TABLE IF NOT EXISTS user_progress (
  user_id         INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  total_exp       INTEGER DEFAULT 0,
  level           INTEGER DEFAULT 1,
  streak          INTEGER DEFAULT 0,
  last_study_date DATE,
  badges          JSONB   DEFAULT '[]'
);

-- Index để tăng tốc truy vấn phổ biến
CREATE INDEX IF NOT EXISTS idx_attempts_user   ON attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_attempts_exam   ON attempts(exam_id);
CREATE INDEX IF NOT EXISTS idx_qstats_user     ON question_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_questions_user  ON questions(user_id);
CREATE INDEX IF NOT EXISTS idx_exams_user      ON exams(user_id);
