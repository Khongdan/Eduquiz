# EduQuiz Pro – Hướng dẫn cài đặt PostgreSQL

## Yêu cầu
- Node.js 18+
- PostgreSQL 14+

---

## 1. Tạo database PostgreSQL

```bash
# Đăng nhập PostgreSQL
psql -U postgres

# Tạo database
CREATE DATABASE eduquiz;
\q
```

---

## 2. Cài đặt Backend

```bash
cd server
npm install

# Sao chép file cấu hình
cp .env.example .env
```

Mở file `server/.env` và chỉnh sửa:
```
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/eduquiz
JWT_SECRET=your_random_secret_string_here
PORT=3001
```

Khởi tạo schema database:
```bash
# Cách 1: dùng script
npm run db:init

# Cách 2: thủ công
psql -U postgres -d eduquiz -f schema.sql
```

Chạy server:
```bash
# Development (tự động reload)
npm run dev

# Production
npm start
```

Server sẽ chạy tại: http://localhost:3001
Kiểm tra: http://localhost:3001/api/health

---

## 3. Cài đặt Frontend

```bash
# Quay lại thư mục gốc
cd ..

# Cài dependencies (nếu chưa có)
npm install

# File .env đã được tạo sẵn với nội dung:
# VITE_API_URL=http://localhost:3001

# Chạy development
npm run dev
```

Frontend sẽ chạy tại: http://localhost:5173

---

## 4. Cấu trúc Database

| Bảng | Mô tả |
|------|-------|
| `users` | Tài khoản người dùng (bcrypt hash password) |
| `questions` | Câu hỏi tùy chỉnh của từng user |
| `exams` | Đề thi tùy chỉnh của từng user |
| `attempts` | Lịch sử làm bài |
| `question_stats` | Thống kê đúng/sai từng câu (SM-2) |
| `user_progress` | Điểm EXP, Level, Streak, Badge |

---

## 5. API Endpoints

```
POST /api/auth/register    – Đăng ký tài khoản
POST /api/auth/login       – Đăng nhập → trả về JWT token

GET  /api/questions        – Lấy câu hỏi của user
POST /api/questions        – Thêm câu hỏi mới
DEL  /api/questions/:id    – Xóa câu hỏi

GET  /api/exams            – Lấy đề thi của user
POST /api/exams            – Tạo đề thi mới
DEL  /api/exams/:id        – Xóa đề thi

GET  /api/attempts         – Lịch sử làm bài
GET  /api/attempts/:id     – Chi tiết một lần làm
POST /api/attempts         – Lưu kết quả làm bài

GET  /api/progress         – Lấy progress (level, streak, badges)
GET  /api/progress/stats   – Lấy question stats (SM-2)
POST /api/progress/stats   – Cập nhật stat sau khi trả lời
```

Tất cả endpoint (trừ auth) yêu cầu header:
```
Authorization: Bearer <JWT_TOKEN>
```

---

## 6. Deploy lên server thật

Nếu deploy lên VPS/cloud, cập nhật:
- `server/.env`: `DATABASE_URL` trỏ đến PostgreSQL server thật
- Frontend `.env`: `VITE_API_URL=https://api.yourdomain.com`
- Build frontend: `npm run build` → serve thư mục `dist/`
