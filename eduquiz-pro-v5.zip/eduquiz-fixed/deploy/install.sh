#!/bin/bash
# ============================================================
#  EduQuiz Pro – Script cài đặt tự động trên Linux
#  Chạy: sudo bash deploy/install.sh
# ============================================================

set -e  # Dừng nếu có lỗi

# ── Màu sắc output ─────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()     { echo -e "${GREEN}✓${NC} $1"; }
info()    { echo -e "${BLUE}ℹ${NC} $1"; }
warn()    { echo -e "${YELLOW}⚠${NC} $1"; }
error()   { echo -e "${RED}✗ LỖI:${NC} $1"; exit 1; }
section() { echo -e "\n${BOLD}${CYAN}── $1 ──────────────────────────────────${NC}"; }

# ── Kiểm tra root ──────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  error "Cần chạy với quyền root: sudo bash deploy/install.sh"
fi

# ── Cấu hình ───────────────────────────────────────────────
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_USER="${SUDO_USER:-eduquiz}"
DOMAIN="${DOMAIN:-localhost}"
SERVER_PORT=3001

echo -e "\n${BOLD}╔══════════════════════════════════════╗"
echo -e "║   EduQuiz Pro – Linux Installer      ║"
echo -e "╚══════════════════════════════════════╝${NC}"
echo ""
info "Thư mục ứng dụng : $APP_DIR"
info "Người dùng hệ thống: $APP_USER"
info "Domain/IP         : $DOMAIN"
echo ""

# ── 1. Cập nhật hệ thống ───────────────────────────────────
section "1. Cập nhật hệ thống"
apt-get update -qq
log "Đã cập nhật package list"

# ── 2. Cài Node.js 20 ─────────────────────────────────────
section "2. Cài đặt Node.js 20"
if ! command -v node &>/dev/null || [[ "$(node -v)" != v20* ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>/dev/null
  apt-get install -y nodejs 2>/dev/null
  log "Node.js $(node -v) đã được cài"
else
  log "Node.js $(node -v) đã có sẵn"
fi

# ── 3. Cài PostgreSQL ──────────────────────────────────────
section "3. Cài đặt PostgreSQL"
if ! command -v psql &>/dev/null; then
  apt-get install -y postgresql postgresql-contrib 2>/dev/null
  systemctl enable postgresql
  systemctl start postgresql
  log "PostgreSQL đã được cài và khởi động"
else
  log "PostgreSQL $(psql --version | awk '{print $3}') đã có sẵn"
  systemctl start postgresql 2>/dev/null || true
fi

# ── 4. Tạo database ────────────────────────────────────────
section "4. Tạo Database"
DB_PASSWORD=$(openssl rand -base64 20 | tr -d '/+=' | head -c 16)
DB_NAME="eduquiz"
DB_USER="eduquiz_user"

# Tạo user và database PostgreSQL
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';" 2>/dev/null || \
  sudo -u postgres psql -c "ALTER USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"

sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;" 2>/dev/null || \
  sudo -u postgres psql -c "ALTER DATABASE $DB_NAME OWNER TO $DB_USER;"

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Khởi tạo schema
export PGPASSWORD="$DB_PASSWORD"
psql -h localhost -U "$DB_USER" -d "$DB_NAME" -f "$APP_DIR/server/schema.sql"
unset PGPASSWORD

log "Database '$DB_NAME' đã được tạo và khởi tạo"

# ── 5. Cài PM2 ─────────────────────────────────────────────
section "5. Cài đặt PM2 (Process Manager)"
if ! command -v pm2 &>/dev/null; then
  npm install -g pm2 --silent
  log "PM2 đã được cài"
else
  log "PM2 $(pm2 -v) đã có sẵn"
fi

# ── 6. Cài Nginx ───────────────────────────────────────────
section "6. Cài đặt Nginx"
if ! command -v nginx &>/dev/null; then
  apt-get install -y nginx 2>/dev/null
  log "Nginx đã được cài"
else
  log "Nginx $(nginx -v 2>&1 | awk -F/ '{print $2}') đã có sẵn"
fi

# ── 7. Tạo file .env cho backend ──────────────────────────
section "7. Cấu hình Backend"
JWT_SECRET=$(openssl rand -base64 48 | tr -d '\n')

cat > "$APP_DIR/server/.env" << ENV
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
JWT_SECRET=${JWT_SECRET}
PORT=${SERVER_PORT}
NODE_ENV=production
FRONTEND_URL=http://${DOMAIN}
ENV

log "File server/.env đã được tạo"

# ── 8. Cài dependencies backend ───────────────────────────
section "8. Cài đặt dependencies Backend"
cd "$APP_DIR/server"
npm install --production --silent
log "Dependencies backend đã được cài"

# ── 9. Build frontend ─────────────────────────────────────
section "9. Build Frontend"
cd "$APP_DIR"

# Tạo .env cho frontend
cat > "$APP_DIR/.env.production" << ENVFE
VITE_API_URL=http://${DOMAIN}/api
ENVFE

npm install --silent
npm run build
log "Frontend đã được build → thư mục dist/"

# ── 10. Cấu hình PM2 ──────────────────────────────────────
section "10. Khởi động Backend với PM2"
cd "$APP_DIR/server"

# Dừng instance cũ nếu có
pm2 delete eduquiz-server 2>/dev/null || true

pm2 start index.js \
  --name "eduquiz-server" \
  --restart-delay 3000 \
  --max-memory-restart 300M \
  --log "$APP_DIR/logs/server.log" \
  --error "$APP_DIR/logs/server-error.log"

pm2 save
pm2 startup systemd -u root --hp /root 2>/dev/null | tail -1 | bash 2>/dev/null || true

log "PM2 đã khởi động eduquiz-server"

# ── 11. Cấu hình Nginx ────────────────────────────────────
section "11. Cấu hình Nginx"
mkdir -p "$APP_DIR/logs"

cat > /etc/nginx/sites-available/eduquiz << NGINX
server {
    listen 80;
    server_name ${DOMAIN};

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml;
    gzip_min_length 1024;

    # Frontend – phục vụ file tĩnh từ dist/
    root ${APP_DIR}/dist;
    index index.html;

    # Cache assets tĩnh (JS, CSS, images)
    location ~* \.(js|css|png|jpg|jpeg|svg|ico|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files \$uri =404;
    }

    # API – proxy tới Express backend
    location /api/ {
        proxy_pass http://127.0.0.1:${SERVER_PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header Connection '';
        proxy_read_timeout 60s;
    }

    # SPA fallback – trả về index.html cho mọi route
    location / {
        try_files \$uri \$uri/ /index.html;
    }

    # Log
    access_log ${APP_DIR}/logs/nginx-access.log;
    error_log  ${APP_DIR}/logs/nginx-error.log;
}
NGINX

# Kích hoạt site
ln -sf /etc/nginx/sites-available/eduquiz /etc/nginx/sites-enabled/eduquiz
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

# Kiểm tra config nginx
nginx -t
systemctl enable nginx
systemctl restart nginx
log "Nginx đã được cấu hình và khởi động lại"

# ── 12. Tạo script quản lý ────────────────────────────────
section "12. Tạo script quản lý"
cat > "$APP_DIR/manage.sh" << 'MANAGE'
#!/bin/bash
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "$1" in
  start)
    echo -e "${GREEN}Khởi động EduQuiz...${NC}"
    pm2 start eduquiz-server
    systemctl start nginx
    ;;
  stop)
    echo -e "${YELLOW}Dừng EduQuiz...${NC}"
    pm2 stop eduquiz-server
    ;;
  restart)
    echo -e "${BLUE}Khởi động lại EduQuiz...${NC}"
    pm2 restart eduquiz-server
    systemctl reload nginx
    ;;
  status)
    echo -e "${BLUE}── Trạng thái Backend (PM2) ──${NC}"
    pm2 show eduquiz-server
    echo -e "\n${BLUE}── Trạng thái Nginx ──${NC}"
    systemctl status nginx --no-pager -l
    ;;
  logs)
    echo -e "${BLUE}── Log Backend ──${NC}"
    pm2 logs eduquiz-server --lines 50
    ;;
  update)
    echo -e "${BLUE}Cập nhật EduQuiz...${NC}"
    cd "$APP_DIR"
    npm install --silent
    npm run build
    cd "$APP_DIR/server"
    npm install --production --silent
    pm2 restart eduquiz-server
    echo -e "${GREEN}✓ Cập nhật hoàn tất!${NC}"
    ;;
  db-backup)
    BACKUP_FILE="$APP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    source "$APP_DIR/server/.env"
    pg_dump "$DATABASE_URL" > "$BACKUP_FILE"
    echo -e "${GREEN}✓ Backup: $BACKUP_FILE${NC}"
    ;;
  *)
    echo "Cách dùng: bash manage.sh [start|stop|restart|status|logs|update|db-backup]"
    ;;
esac
MANAGE

chmod +x "$APP_DIR/manage.sh"
log "Script manage.sh đã được tạo"

# ── Kiểm tra health ────────────────────────────────────────
section "Kiểm tra hệ thống"
sleep 2
if curl -sf "http://localhost:${SERVER_PORT}/api/health" | grep -q "connected"; then
  log "Backend API: OK"
else
  warn "Backend chưa phản hồi — kiểm tra: pm2 logs eduquiz-server"
fi

if curl -sf "http://localhost/" | grep -q "html"; then
  log "Frontend Nginx: OK"
else
  warn "Nginx chưa phản hồi — kiểm tra: nginx -t"
fi

# ── Tóm tắt ───────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════╗"
echo -e "║         CÀI ĐẶT HOÀN TẤT! 🎉              ║"
echo -e "╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🌐 Truy cập ứng dụng : ${CYAN}http://${DOMAIN}${NC}"
echo -e "  🔌 Backend API        : ${CYAN}http://${DOMAIN}/api/health${NC}"
echo ""
echo -e "  📋 Quản lý ứng dụng:"
echo -e "     ${YELLOW}bash manage.sh start${NC}    – Khởi động"
echo -e "     ${YELLOW}bash manage.sh stop${NC}     – Dừng"
echo -e "     ${YELLOW}bash manage.sh restart${NC}  – Khởi động lại"
echo -e "     ${YELLOW}bash manage.sh logs${NC}     – Xem log"
echo -e "     ${YELLOW}bash manage.sh update${NC}   – Cập nhật code mới"
echo -e "     ${YELLOW}bash manage.sh db-backup${NC}– Backup database"
echo ""
echo -e "  📁 Thông tin đã lưu vào: ${YELLOW}$APP_DIR/server/.env${NC}"
echo ""
