// PM2 Ecosystem Config – EduQuiz Pro
// Dùng: pm2 start deploy/ecosystem.config.js

const path = require("path");
const APP_DIR = path.resolve(__dirname, "..");

module.exports = {
  apps: [
    {
      name: "eduquiz-server",
      script: path.join(APP_DIR, "server/index.js"),
      cwd: path.join(APP_DIR, "server"),

      // Môi trường production
      env: {
        NODE_ENV: "production",
      },

      // Khởi động lại tự động
      restart_delay: 3000,
      max_restarts: 10,
      min_uptime: "5s",

      // Giới hạn bộ nhớ (tự restart nếu vượt 300MB)
      max_memory_restart: "300M",

      // Log
      out_file: path.join(APP_DIR, "logs/server.log"),
      error_file: path.join(APP_DIR, "logs/server-error.log"),
      merge_logs: true,
      log_date_format: "YYYY-MM-DD HH:mm:ss",

      // Không watch file trong production
      watch: false,
    },
  ],
};
