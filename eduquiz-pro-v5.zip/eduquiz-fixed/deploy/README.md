# EduQuiz Pro – Hướng dẫn Deploy Linux

## Kiến trúc hệ thống

```
Internet
    │
    ▼
┌─────────────────────────────────────────┐
│  Nginx :80                              │
│  ├── /          → dist/ (React SPA)     │
│  └── /api/      → localhost:3001        │
└─────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────┐
│  Express.js :3001  (PM2)                │
│  ├── /api/auth                          │
│  ├── /api/questions                     │
│  ├── /api/exams                         │
│  ├── /api/attempts                      │
│  └── /api/progress                      │
└─────────────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────┐
│  PostgreSQL :5432                       │
│  Database: eduquiz                      │
└─────────────────────────────────────────┘
```

---

## Cách 1: Cài đặt tự động (Khuyến nghị)

```bash
# Copy project lên server
scp -r eduquiz-fixed/ user@your-server:/opt/eduquiz

# SSH vào server
ssh user@your-server

# Chạy script cài đặt tự động
cd /opt/eduquiz
sudo bash deploy/install.sh
```

Script tự động làm tất cả:
- Cài Node.js 20, PostgreSQL, Nginx, PM2
- Tạo database + user PostgreSQL ngẫu nhiên
- Chạy schema.sql khởi tạo bảng
- Build frontend React
- Cấu hình Nginx reverse proxy
- Khởi động backend với PM2
- Tạo script manage.sh để quản lý

---

## Cách 2: Cài đặt thủ công từng bước

### Bước 1 – Cài Node.js 20
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs
node -v   # phải thấy v20.x.x
```

### Bước 2 – Cài PostgreSQL
```bash
sudo apt-get install -y postgresql postgresql-contrib
sudo systemctl enable postgresql
sudo systemctl start postgresql
```

### Bước 3 – Tạo database
```bash
sudo -u postgres psql << SQL
CREATE USER eduquiz_user WITH PASSWORD 'your_strong_password';
CREATE DATABASE eduquiz OWNER eduquiz_user;
GRANT ALL PRIVILEGES ON DATABASE eduquiz TO eduquiz_user;
SQL

# Khởi tạo bảng
PGPASSWORD=your_strong_password psql -h localhost -U eduquiz_user -d eduquiz -f server/schema.sql
```

### Bước 4 – Cấu hình backend
```bash
cd server
cp .env.example .env
nano .env  # điền DATABASE_URL và JWT_SECRET
```

File `.env`:
```
DATABASE_URL=postgresql://eduquiz_user:your_strong_password@localhost:5432/eduquiz
JWT_SECRET=random_string_at_least_32_chars
PORT=3001
NODE_ENV=production
```

### Bước 5 – Cài PM2 và chạy backend
```bash
sudo npm install -g pm2
cd server
npm install --production
pm2 start deploy/ecosystem.config.js
pm2 save
pm2 startup   # copy và chạy lệnh được in ra
```

### Bước 6 – Build frontend
```bash
cd /opt/eduquiz
echo "VITE_API_URL=http://your-server-ip/api" > .env.production
npm install
npm run build
```

### Bước 7 – Cài và cấu hình Nginx
```bash
sudo apt-get install -y nginx

# Copy config mẫu
sudo cp deploy/nginx.conf.template /etc/nginx/sites-available/eduquiz

# Sửa đường dẫn và domain
sudo nano /etc/nginx/sites-available/eduquiz

# Kích hoạt
sudo ln -s /etc/nginx/sites-available/eduquiz /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl restart nginx
```

---

## Quản lý sau khi cài đặt

```bash
bash manage.sh start      # Khởi động
bash manage.sh stop       # Dừng
bash manage.sh restart    # Khởi động lại
bash manage.sh status     # Xem trạng thái
bash manage.sh logs       # Xem log realtime
bash manage.sh update     # Cập nhật code mới
bash manage.sh db-backup  # Backup database
```

---

## Thêm HTTPS với Let's Encrypt (Có domain thật)

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
sudo systemctl reload nginx
```

Certbot tự sửa nginx config và tự gia hạn certificate.

---

## Kiểm tra hệ thống

```bash
# Backend đang chạy?
curl http://localhost:3001/api/health
# {"status":"ok","db":"connected"}

# Nginx đang phục vụ?
curl http://localhost/
# HTML của trang chủ

# PM2 status
pm2 status

# PostgreSQL có kết nối?
sudo -u postgres psql -d eduquiz -c "SELECT COUNT(*) FROM users;"
```
